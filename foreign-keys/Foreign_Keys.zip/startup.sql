\set ECHO 'none'
\set QUIET 'on'
\pset footer off
\set PROMPT1 '%R%  '
\set PROMPT2 '%R%  '
\set VERBOSITY 'default'
\set AUTOCOMMIT True
