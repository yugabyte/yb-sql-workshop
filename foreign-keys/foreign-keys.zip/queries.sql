-- bare orders.
select
  order_pk,
  customer_pk,
  order_timestamp
from orders
order by customer_pk, order_timestamp;

--------------------------------------------------------------------------------
-- List the orders for a specified customer.
with

  orders_with_customer_name as (
    select
      o.order_pk,
      c.customer_name,
      o.order_timestamp
    from orders o inner join customers c using(customer_pk))

select
  order_pk,
  order_timestamp
from orders_with_customer_name
where customer_name = 'Helen'
order by order_timestamp;

--------------------------------------------------------------------------------
-- orders with customer_name and item_pk
with

  orders_with_customer_name as (
    select
      o.order_pk,
      c.customer_name,
      o.order_timestamp
    from orders o inner join customers c using(customer_pk)),

  orders_with_customer_name_and_item_pk as (
    select
      order_pk,
      o.customer_name,
      o.order_timestamp,
      ol.item_pk,
      ol.quantity
    from
    order_lines ol inner join orders_with_customer_name o using(order_pk))

select
  order_pk,
  customer_name,
  order_timestamp,
  item_pk,
  quantity 
from orders_with_customer_name_and_item_pk
order by customer_name, order_timestamp;

--------------------------------------------------------------------------------
-- List the items for order #1.
with

  orders_with_customer_name as (
    select
    o.order_pk as order_pk,
    c.customer_name as customer_name,
    o.order_timestamp as order_timestamp
    from orders o inner join customers c using(customer_pk)),

  orders_with_customer_name_and_item_pk as (
    select
      order_pk,
      O.customer_name,
      O.order_timestamp,
      ol.item_pk, ol.quantity
    from order_lines ol
    inner join orders_with_customer_name o
    using(order_pk)),

  orders_with_customer_name_and_item_name as (
    select
      o.order_pk,
      o.customer_name,
      o.order_timestamp,
      i.item_name,
      i.price,
      o.quantity
    from orders_with_customer_name_and_item_pk o
    inner join items i
    using(item_pk))

select
  customer_name,
  order_timestamp,
  item_name,
  price,
  quantity
from orders_with_customer_name_and_item_name
where order_pk = 1
order by customer_name, order_timestamp;

--------------------------------------------------------------------------------
-- Compute total cost of order of an order for a given order number.
with

  orders_with_customer_name as (
    select
      o.order_pk as order_pk,
      c.customer_name as customer_name,
      o.order_timestamp as order_timestamp
    from orders o inner join customers c using(customer_pk)),

  orders_with_customer_name_and_item_pk as (
    select
      order_pk,
      o.customer_name,
      o.order_timestamp,
      ol.item_pk,
      ol.quantity
    from
    order_lines ol
    inner join orders_with_customer_name o
    using(order_pk)),

  orders_with_customer_name_and_item_name as (
    select
      o.order_pk,
      o.customer_name,
      o.order_timestamp,
      I.item_name,
      I.price,
      o.quantity
    from orders_with_customer_name_and_item_pk o
    inner join items i
    using(item_pk))

select
  customer_name,
  order_timestamp,
  sum(price*quantity) total
from orders_with_customer_name_and_item_name
where order_pk = 1
group by order_pk, customer_name, order_timestamp
order by customer_name, order_timestamp;
