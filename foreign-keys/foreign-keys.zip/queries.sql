\echo
\echo Basic two-table inner join.
\echo List all the orders.
select
  c.customer_name as "customer",
  o.order_pk as "order#",
  to_char(o.order_timestamp, 'Mon-dd hh24:mi') as "date"
from orders o inner join customers c using(customer_pk)
order by c.customer_name, o.order_pk;
--------------------------------------------------------------------------------

\echo
\echo List everything with an inner join between all four tables.
select
  c.customer_name as "name",
  order_pk as "order#",
  to_char(o.order_timestamp, 'Mon-dd hh24:mi') as "date",
  i.item_name as "item",
  i.price,
  ol.quantity as "qty"
from order_lines ol inner join orders o using (order_pk)
inner join customers c using (customer_pk)
inner join items i using (item_pk)
order by c.customer_name, order_pk, item_name;
--------------------------------------------------------------------------------

\echo
\echo List the items for order #1.
select
  c.customer_name as "customer",
  to_char(o.order_timestamp, 'Mon-dd hh24:mi') "timestamp",
  i.item_name as "item",
  i.price,
  ol.quantity as "qty"
from order_lines ol inner join orders o using (order_pk)
inner join customers c using (customer_pk)
inner join items i using (item_pk)
where order_pk = 1
order by i.item_name;

--------------------------------------------------------------------------------
\echo
\echo Compute the total cost of all orders.
select
  c.customer_name as "name",
  order_pk as "order#",
  to_char(o.order_timestamp, 'Mon-dd hh24:mi') as "date",
  sum(i.price*ol.quantity) as "total"
from order_lines ol inner join orders o using (order_pk)
inner join customers c using (customer_pk)
inner join items i using (item_pk)
group by customer_name, order_pk, order_timestamp
order by customer_name, order_pk;
