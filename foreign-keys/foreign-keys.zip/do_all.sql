\i startup.sql
\i cr_tables.sql
\i populate_tables.sql
\i queries.sql
\i DMLs.sql
