
-- psql -h 127.0.0.1 -p 5432 -d postgres -U postgres -f do_all.sql > pg.txt
-- ysql -h 127.0.0.1 -p 5433 -d yugabyte -U yugabyte -f do_all.sql > yb.txt

\i startup.sql
\i cr_tables.sql
\i populate_tables.sql
\i queries.sql
\i DMLs.sql
