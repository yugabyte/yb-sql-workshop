-- Delete an un-referenced item.
begin isolation level serializable;
delete from items where item_name = 'toothpaste';
commit;

-- Try to delete a refereced item.
-- Errors with "...violates foreign key constraint..."
begin isolation level serializable;
delete from items where item_name = 'aspirin';
commit;

-- Cascade-delete a customer.
begin isolation level serializable;
delete from customers where customer_name = 'Helen';
commit;

-- Notice the consequential deletes from orders and order_lines.
select count(*) from orders;
select count(*) from order_lines;

-- Try to create an order line for an order that doesn't exist.

begin isolation level serializable;
insert into order_lines(order_pk, item_pk, quantity)
values(
  -- There is no order #42.
  42,
  (select item_pk
   from items
   where item_name = 'aspirin'),
  2);
commit;
