-- Delete an un-referenced item.
delete from items where item_name = 'razor blades';

-- Try to delete a refereced item.
-- Errors with:
-- ...violates foreign key constraint...
-- Key... is still referenced from table "order_lines".
delete from items where item_name = 'aspirin';

\echo Before cascade-delete Helen.
select count(*) from orders;
select count(*) from order_lines;

-- Delete Helen.
delete from customers where customer_name = 'Helen';

\echo After cascade-delete Helen.
\echo Notice the consequential deletes from orders and order_lines.
select count(*) from orders;
select count(*) from order_lines;

-- Try to create an order line for an order that doesn't exist.
-- Errors with "...violates foreign key constraint..."
--  Key... is not present in table "orders".
insert into order_lines(order_pk, item_pk, quantity)
values(
  -- There is no order #42.
  42,
  (select item_pk
   from items
   where item_name = 'aspirin'),
  3);
