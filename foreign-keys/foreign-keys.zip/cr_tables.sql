drop table if exists order_lines;
drop table if exists orders;
drop table if exists items;
drop table if exists customers;

------------------------------------------------------------
-- customers

create table customers(
  customer_pk int
    generated always as identity,

  customer_name text
    constraint customer_name_nn not null
    constraint customer_name_unq unique,

  constraint customers_pk primary key(customer_pk));

------------------------------------------------------------
-- items

create table items(
  item_pk int
    generated always as identity,

  item_name text
    constraint items_name_nn not null
    constraint items_name_unq unique,

  price money
    constraint price_nn not null,

    constraint items_items_pk primary key(item_pk));

------------------------------------------------------------
-- orders

create table orders(
  order_pk int
    generated always as identity,

  customer_pk int
    constraint customer_pk_nn not null,

  -- Implicitly coerce all timestamp values to UTC
  order_timestamp timestamp
    default current_timestamp
    constraint order_timestamp_nn not null,

  constraint orders_pk primary key(order_pk),

  constraint customer_pk_fk foreign key(customer_pk)
    references customers(customer_pk)
    match full
    on delete cascade
    on update restrict);

create index orders_customer_pk on orders(customer_pk);
------------------------------------------------------------
-- order_lines

create table order_lines(
  order_pk int
    constraint order_pk_nn not null,

  item_pk int
    constraint item_pk_nn not null,

  quantity int
    constraint quantity_nn not null
    constraint quantity_n_neg check (quantity > 0),

  constraint order_lines_pk primary key(order_pk, item_pk),

  constraint order_pk_fk foreign key(order_pk)
    references orders(order_pk)
    match full
    on delete cascade
    on update restrict,

  constraint item_pk_fk foreign key(item_pk)
    references items(item_pk)
    match full
    on delete restrict
    on update restrict);

create index order_lines_order_pk on order_lines(order_pk);

create index order_lines_item_pk on order_lines(item_pk);
