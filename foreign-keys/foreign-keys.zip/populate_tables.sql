begin isolation level serializable;

-- Create some customers.
insert into customers(customer_name)
values
  ('Mary'),
  ('Alice'),
  ('Helen'),
  ('Bill'),
  ('Dave'),
  ('John');

-- Create some items.
insert into items(item_name, price)
values
  ('after shave', 8.99),
  ('deodorant',   5.99),
  ('soap',        2.99),
  ('toothpaste',  2.99),
  ('aspirin',     9.99),
  ('cotton wool', 3.99);

-- Create an empty order for a customer
-- and note the value of the generated order_pk.
insert into orders(customer_pk)
values(
  (select customer_pk
   from customers
   where customer_name = 'Helen'))
returning order_pk;

-- Add lines to an order for the specifed quantity of a particular item.
insert into order_lines(order_pk, item_pk, quantity)
values(
  -- this is the value that was noted programmatically
  -- when the order was created.
  1,
  (select item_pk
   from items
   where item_name = 'soap'),
   5);

insert into order_lines(order_pk, item_pk, quantity)
values(
  1,
  (select item_pk
   from items
   where item_name = 'aspirin'),
   2);

commit;
