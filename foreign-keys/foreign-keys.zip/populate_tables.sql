\echo
\echo Create some customers.
insert into customers(customer_name)
values
  ('Mary'),
  ('Alice'),
  ('Helen'),
  ('Bill'),
  ('Dave'),
  ('John');

\echo
\echo Create some items.
insert into items(item_name, price)
values
  ('after shave',  8.99),
  ('deodorant',    5.99),
  ('soap',         2.99),
  ('toothpaste',   2.99),
  ('razor blades', 9.99),
  ('aspirin',      7.99),
  ('cotton wool',  3.99);
--------------------------------------------------------------------------------

\echo
\echo Create an empty order for Helen
\echo and note the value of the generated order_pk.
insert into orders(customer_pk)
values(
  (select customer_pk
   from customers
   where customer_name = 'Helen'))
returning order_pk;

\echo
\echo Add one order line for the specifed quantity of a particular item.
insert into order_lines(order_pk, item_pk, quantity)
values(
  -- this is the value that was noted programmatically
  -- when the order was created.
  1,
  (select item_pk
   from items
   where item_name = 'soap'),
  5);

\echo
\echo Add several more order lines for the specifed quantities of various items.
insert into order_lines(order_pk, item_pk, quantity)
select
  1, -- the order number
  item_pk,
  case item_name
    when 'aspirin'     then 2
    when 'toothpaste'  then 1
    when 'cotton wool' then 8
  end as quantity
from items
where item_name in ('aspirin', 'toothpaste', 'cotton wool');

--------------------------------------------------------------------------------

\echo
\echo Make sure that the order for Dave has a different timestamp
\echo from the order for Helen.
\echo sleeping...
select pg_sleep(120) as "pg_sleep for 2 minutess";
\echo slept

\echo
\echo Create an empty order for Dave
\echo and insert several order lines

insert into orders(customer_pk)
values(
  (select customer_pk
   from customers
   where customer_name = 'Dave'))
returning order_pk;

insert into order_lines(order_pk, item_pk, quantity)
select
  2, -- the order number
  item_pk,
  case item_name
    when 'after shave' then 5
    when 'deodorant'   then 7
    when 'soap'        then 3
    when 'aspirin'     then 4
    when 'cotton wool' then 5
  end as quantity
from items
where item_name in
  ('after shave', 'deodorant', 'soap', 'aspirin', 'cotton wool');

--------------------------------------------------------------------------------

\echo
\echo Make sure that the second order for Helen has a different timestamp
\echo than the one for Dave.
\echo sleeping...
select pg_sleep(180) as "pg_sleep for 3 minutes";
\echo slept

\echo
\echo Create a second empty order for Helen
\echo and insert several order lines
insert into orders(customer_pk)
values(
  (select customer_pk
   from customers
   where customer_name = 'Helen'))
returning order_pk;

insert into order_lines(order_pk, item_pk, quantity)
select
  3, -- the order number
  item_pk,
  case item_name
    when 'after shave' then 3
    when 'deodorant'   then 2
    when 'soap'        then 5
    when 'toothpaste'  then 7
    when 'aspirin'     then 8
    when 'cotton wool' then 4
  end as quantity
from items
where item_name in
  ('after shave', 'deodorant', 'soap',
   'toothpaste', 'aspirin', 'cotton wool');
