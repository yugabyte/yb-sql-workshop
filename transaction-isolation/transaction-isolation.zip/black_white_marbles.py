"""'Black and White Marbles' scenario to illustrate transaction isolation levels"""

# At the "(venv) $" prompt:
# python black_white_marbles.py --db=yb --lvl=snp > black_white_marbles_output/yb_snp.txt
# python black_white_marbles.py --db=yb --lvl=srl > black_white_marbles_output/yb_srl.txt
# python black_white_marbles.py --db=pg --lvl=snp > black_white_marbles_output/pg_snp.txt
# python black_white_marbles.py --db=pg --lvl=srl > black_white_marbles_output/pg_srl.txt

import argparse
import cmn

# ------------------------------------------------------------------------------------------

def parse_arguments():
    parser = argparse.ArgumentParser("Isolation Levels Tests")

    parser.add_argument(
        "--db",
        choices=['yb', 'pg'],
        default="yb",
        help="Database: yb to use YugaByte, pg to use Postgres")

    parser.add_argument(
        "--lvl",
        choices=['snp', 'srl', 'mx1', 'mx2'],
        default="snp",
        help="""
        snp = both sessions snapshot,
        srl = both sessions serializable,
        mx1 = Sees_1 snp & Sess_2 srl,
        mx2 = Sees_1 srl & Sess_2 snp
        """)

    return parser.parse_args()

# ------------------------------------------------------------------------------------------

class Stmts:
    drop_table = cmn.Stmt(
        "drop table",
        "drop table if exists marbles")

    create_table = cmn.Stmt(
        "create table",
        """
        create table marbles(
          k int
            constraint t_k primary key,
          color text
            constraint t_c1_nn not null
            constraint t_c1_chk check(color in ('black', 'white')))
        """)

    insert_two_rows = cmn.Stmt(
        "insert one black row and one white row",
        """
        insert into marbles(k, color) values
          (1, 'black'),
          (2, 'white')
        """)

    show_marbles = cmn.Stmt(
        "select * from marbles",
        "select k, color from marbles order by k")

    set_black_marble_to_white = cmn.Stmt(
        "set black marble to white",
        "update marbles set color = 'white' where color = 'black'")

    set_white_marble_to_black = cmn.Stmt(
        "set white marble to black",
        "update marbles set color = 'black' where color = 'white'")

# ------------------------------------------------------------------------------------------

def show_marbles(sess):
    # Notice that if a serialization error has been detetcted,
    # then "execute" will be a no-op.
    sess.execute(Stmts.show_marbles, report_stmts = True)
    if (not sess.serialization_error):
        rows = sess.cur.fetchall()
        for row in rows:
            print(sess.padding + str(row[0]).ljust(4, ' ') + row[1])

# ------------------------------------------------------------------------------------------

def create_table(params):
    # We can safely take advantage of AUTOCOMMIT for these single-session DDLs.
    sess = cmn.Session(params, "", report_stmts = False)
    sess.execute(Stmts.drop_table)
    sess.execute(Stmts.create_table)
    sess.close()
    print("Table dropped & created.")

# ------------------------------------------------------------------------------------------

def show_committed_status(params):
    # We can safely take advantage of AUTOCOMMIT for this single-session Query.
    sess = cmn.Session(params, params.sess_1_padding, report_stmts = False)
    show_marbles(sess)
    sess.close()
    print("(Final committed status using separate session.)")

# ------------------------------------------------------------------------------------------

def insert_two_rows(params):
    # We can safely take advantage of AUTOCOMMIT for this single-session Query.
    sess = cmn.Session(params, "", report_stmts = False)
    sess.execute(Stmts.insert_two_rows)
    print("Inserted two rows (using separate session).")
    show_marbles(sess)
    sess.close()

# ------------------------------------------------------------------------------------------

def main():
    cmn.rule_off("~")
    print("\n*** Black/White Marbles ***")

    args = parse_arguments()
    params = cmn.Params(args.db, args.lvl)
    create_table(params)
    insert_two_rows(params)
    two_sessions = cmn.TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.set_black_marble_to_white)
    two_sessions.sess_2.execute(Stmts.set_white_marble_to_black)
    two_sessions.close()
    show_committed_status(params)

# ------------------------------------------------------------------------------------------

if __name__ == '__main__':
    main()
