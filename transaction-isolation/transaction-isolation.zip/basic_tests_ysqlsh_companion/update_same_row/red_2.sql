\echo update t set v = 42 where k = 2;

update t set v = 42 where k = 2;

\echo "update" attempt has now completed
