\echo update t set v = 17 where k = 2;

update t set v = 17 where k = 2;
