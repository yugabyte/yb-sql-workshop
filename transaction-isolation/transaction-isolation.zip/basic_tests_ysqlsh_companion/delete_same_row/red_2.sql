\echo delete from t where k = 2

delete from t where k = 2;

\echo "delete" has now completed
