\echo insert into t(k, v) values(17, 34);

insert into t(k, v) values(17, 34);

\echo "insert" attempt has now completed
