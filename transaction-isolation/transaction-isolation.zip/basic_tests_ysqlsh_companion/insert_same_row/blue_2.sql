\insert into t(k, v) values(17, 42);

insert into t(k, v) values(17, 42);
