\i select_star.sql
