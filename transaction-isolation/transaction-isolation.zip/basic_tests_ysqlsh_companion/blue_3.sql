\echo commit
commit;
\i select_star.sql
