\echo select *
select k, v from t order by k;
