\echo set isolation level

\set AUTOCOMMIT on
\i set_isolation_level.sql
