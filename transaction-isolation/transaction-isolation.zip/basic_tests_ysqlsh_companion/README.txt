Read the section "The ysqlsh companion tests for the basic tests" in the README.md
for the comanion cpde zip, here:

https://github.com/YugaByte/yb-sql-workshop/tree/master/transaction-isolation#the-ysqlsh-companion-tests-for-the-basic-tests