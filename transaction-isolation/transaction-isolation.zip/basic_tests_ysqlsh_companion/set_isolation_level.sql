begin;
-- set transaction isolation level read committed;  -- PG only
   set transaction isolation level repeatable read; -- a.k.a. "snapshot level"
-- set transaction isolation level serializable;
