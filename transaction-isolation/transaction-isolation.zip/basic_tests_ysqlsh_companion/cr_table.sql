drop table if exists t;
create table t(k int primary key, v int not null unique);
with s as (select generate_series(1, 3) as a)
insert into t(k, v) select a as k, a*2 as v from s;
