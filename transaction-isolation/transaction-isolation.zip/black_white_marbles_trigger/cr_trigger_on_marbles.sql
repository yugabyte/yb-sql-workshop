drop trigger if exists check_marbles_rule on marbles;

create or replace function marbles_rule()
  returns trigger
  language plpgsql
as
$$
declare
  v int;
begin
  select count(distinct color)
  into v
  from marbles
  where color in ('black', 'white');
  if v not in (0, 1) then
    raise exception
      'all marbles must be either black or white'
      using errcode = '99999';
  end if;
  return null;
end;
$$;

create trigger check_marbles_rule
  after update or insert or delete
  on marbles
  for statement
  execute procedure marbles_rule();
