The filenames are self-explanatory. Look at them first, in this order:

1. cmn.py
2. black_white_marbles.py
3. admin_cmn.py
4. one_or_two_admins
5. retry_loop.py
6. basic_tests.py

Use this as the "how to use" source of truth:

https://github.com/YugaByte/yb-sql-workshop/tree/master/transaction-isolation/README.md

It also explains what the various subdirectories are for.
