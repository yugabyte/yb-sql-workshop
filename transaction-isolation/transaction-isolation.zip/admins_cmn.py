"""Common services for one_or_two_admins.py and retry_loop.py"""

import psycopg2
import cmn

# ------------------------------------------------------------------------------------------

class Stmts:
    drop_table = cmn.Stmt(
        "drop table",
        "drop table if exists staff cascade")

    create_table = cmn.Stmt(
        "create table",
        """
        create table staff(
          name varchar(10)
            constraint staff_name primary key,
          job varchar(10)
            constraint staff_job_nn not null
            constraint staff_job_chk check (job in (
              'Manager',
              'Admin',
              'Sales',
              'Marketing',
              'Developer')))
        """)

    create_index = cmn.Stmt(
        "create index",
        "create index staff_job_idx on staff(job)")

    delete_all_rows = cmn.Stmt(
        "delete all rows",
        "delete from staff")

    insert_six_rows = cmn.Stmt(
        "insert six rows",
        """
        insert into staff(name, job) values
          ('Mary',  'Manager'),
          ('Maude', 'Developer'),
          ('Susan', 'Sales'),
          ('Bill',  'Marketing'),
          ('Fred',  'Sales'),
          ('John',  'Admin')
        """)

    highlight_admins = cmn.Stmt(
        "highlight the Admin staff",
        """
        select
          case
            when job = 'Admin' then '>>>'
          else                      ' '
            end
          as is_staff,
          name,
          job
        from staff
        order by name
        """)

    check_one_or_two_admins = cmn.Stmt(
        "check one or two Admin staff",
        """
        select 
          case (select count(*) from staff where job = 'Admin') in (1, 2)
            when true then 'PASSED!'
            else           'FAILED!'
          end
          as assertion
        """)

    insert_alice_as_admin = cmn.Stmt(
        "insert Alice as Admin",
        "insert into staff(name, job) values ('Alice', 'Admin')")

    insert_alice_as_developer = cmn.Stmt(
        "insert Alice as Developer",
        "insert into staff(name, job) values ('Alice', 'Developer')")

    insert_bert_as_admin = cmn.Stmt(
        "insert Bert as Admin",
        "insert into staff(name, job) values ('Bert', 'Admin')")

    insert_bert_as_sales = cmn.Stmt(
        "insert Bert as Sales",
        "insert into staff(name, job) values ('Bert', 'Sales')")

    delete_admin_john = cmn.Stmt(
        "delete Admin John",
        "delete from staff where name = 'John'")

    delete_admin_alice = cmn.Stmt(
        "delete Admin Alice",
        "delete from staff where name = 'Alice'")

    update_susan_from_sales_to_admin = cmn.Stmt(
        "update Susan from Sales to Admin",
        "update staff set job = 'Admin' where name = 'Susan'")

    update_mary_from_manager_to_admin = cmn.Stmt(
        "update Mary from Manager to Admin",
        "update staff set job = 'Admin' where name = 'Mary'")

    update_john_from_admin_to_sales = cmn.Stmt(
        "update John from Admin to Sales",
        "update staff set job = 'Sales' where name = 'John'")

    update_alice_from_admin_to_developer = cmn.Stmt(
        "update Alice from Admin to Developer",
        "update staff set job = 'Developer' where name = 'Alice'")

# ------------------------------------------------------------------------------------------

def highlight_admins(sess):
    sess.execute(Stmts.highlight_admins, True)
    if (not sess.serialization_error):
        rows = sess.cur.fetchall()
        for row in rows:
            print(sess.padding + row[0].ljust(4, ' ') + row[1].ljust(8, ' ') + row[2])

# ------------------------------------------------------------------------------------------

def check_one_or_two_admins(sess, do_rule_off = None):
    if do_rule_off is None:
        l_do_rule_off = sess.do_rule_off
    else:
        l_do_rule_off = do_rule_off
    sess.execute(Stmts.check_one_or_two_admins, report_stmts = True, do_rule_off = l_do_rule_off)

    if (not sess.serialization_error):
        rows = sess.cur.fetchall()
        assert (len(rows) == 1), "SQL logic error in check_one_or_two_admins.sql_text"
        print(sess.padding + rows[0][0])

# ------------------------------------------------------------------------------------------

def create_table(params):
    # We can safely take advantage of AUTOCOMMIT for these single-session DDLs.
    sess = cmn.Session(params, "", report_stmts = False)
    sess.execute(Stmts.drop_table)
    sess.execute(Stmts.create_table)
    sess.execute(Stmts.create_index)
    sess.close()
    print("\nTable dropped & created.\n")

# ------------------------------------------------------------------------------------------

def populate_staff_with_one_admin(params):
    # We can safely take advantage of AUTOCOMMIT for these single-session DMLs.
    sess = cmn.Session(params, "", report_stmts = False)
    sess.execute(Stmts.delete_all_rows)
    sess.execute(Stmts.insert_six_rows)
    highlight_admins(sess)
    print("")
    check_one_or_two_admins(sess, do_rule_off = False)
    sess.close()

# ------------------------------------------------------------------------------------------

def populate_staff_with_two_admins(params):
    # We can safely take advantage of AUTOCOMMIT for these single-session DMLs.
    sess = cmn.Session(params, "", report_stmts = False)
    sess.execute(Stmts.delete_all_rows)
    sess.execute(Stmts.insert_six_rows)
    sess.execute(Stmts.insert_alice_as_admin)
    highlight_admins(sess)
    print("")
    check_one_or_two_admins(sess, do_rule_off = False)
    sess.close()

# ------------------------------------------------------------------------------------------

def show_committed_status(params):
    # We can safely take advantage of AUTOCOMMIT for this single-session Query.
    sess = cmn.Session(params, params.sess_1_padding, report_stmts = False)
    highlight_admins(sess)
    print("")
    check_one_or_two_admins(sess, do_rule_off = False)
    sess.close()
    print("(Final committed status using separate session.)")
