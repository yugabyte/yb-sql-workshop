"""Retry loop for 'one or two admins' scenario"""

# At the "(venv) $" prompt:
# For example:
#
# python retry_loop.py --mode='setup_two_admins' --db=yb                   > retry_loop_output/setup_two_admins_yb.txt
#
# Snapshot
# python retry_loop.py --mode='delete_admin' --db=yb --lvl=snp --sesno='1' > retry_loop_output/delete_admin_yb_snp_1.txt
# python retry_loop.py --mode='delete_admin' --db=yb --lvl=snp --sesno='2' > retry_loop_output/delete_admin_yb_snp_2.txt
#
# Serializable
# python retry_loop.py --mode='delete_admin' --db=yb --lvl=srl --sesno='1' > retry_loop_output/delete_admin_yb_srl_1.txt
# python retry_loop.py --mode='delete_admin' --db=yb --lvl=srl --sesno='2' > retry_loop_output/delete_admin_yb_srl_2.txt
#
# python retry_loop.py --mode='show_result' --db=yb                        > retry_loop_output/show_result_yb.txt

import argparse
import cmn
import admins_cmn
import psycopg2
import time
import datetime

# ------------------------------------------------------------------------------------------

# The high level aim here is to run two executions of this program concurrently,
# each in its own terminal window, in such a way that the SQL executions from each
# exactly interleave. The approach is naïve, but good enough.
#
# Notice that this program also has "setup" and "show result" modes. The following
# account, on timing, is relevant for the modes that are used when two invocations
# of this program are run concurrently.
#
# The program constant SLEEP_TIME determines the time between "start transaction"
# and each subsequent SQL execution.
#
# The optional command-line argument "start_at" is relevant for the concurrent modes.
# Set it to a little bit ahead of the current wall clock time before starting the
# two invocations, each in its own terminal window. The program sleeps until the
# wall clock time reaches "start_at". Then the invocation started with "sessno=1"
# starts immediately and the invocation started  with "sessno=1" starts after a
# further SLEEP_TIME/2 seconds.
#
# You can confirm that this approach works for by looking at the value for
# "seconds since start" that is printed before each SQL statement execution.

SLEEP_TIME = 4  # seconds

# ------------------------------------------------------------------------------------------

def parse_arguments():
    parser = argparse.ArgumentParser("Serialization error retry loop")

    parser.add_argument(
        "--start_at",
        help="E.g. 2019-09-18 22:35:00")

    parser.add_argument(
        "--mode",
        choices=['setup_two_admins', 'setup_one_admin', 'show_result',  # Single session modes.
                 'delete_admin', 'update_admin', 'insert_admin',        # Modes for two
                 'insert_collision', 'insert_benign'],                  #   concurrent sessions.
        default='show_result',
        help="several distinct modes")

    parser.add_argument(
        "--lvl",
        choices=['snp', 'srl'],
        default="snp",
        help="Isolation level: snp for snapshot, srl for serializable")

    parser.add_argument(
        "--sesno",
        choices=['1', '2'],
        default='1',
        help="Session #")

    parser.add_argument(
        "--db",
        choices=['yb', 'pg'],
        default="yb",
        help="Database: yb to use YugaByte, pg to use Postgres")

    return parser.parse_args()

# ------------------------------------------------------------------------------------------

def sleep_and_return_time_since_start(start_time, sleep_time):
    time.sleep(sleep_time)
    now = datetime.datetime.now()
    delta = now - start_time
    # display to one decimal place.
    s = "{:.1f}".format(delta.total_seconds())
    return "\nAfter" + s.rjust(5) + " seconds: "

# ------------------------------------------------------------------------------------------

def setup_one_admin(params):
    cmn.rule_off("~")
    print("\n*** Retry loop — setup_two_admins ***")
    admins_cmn.create_table(params)
    admins_cmn.populate_staff_with_one_admin(params)
    cmn.rule_off("~")

# ------------------------------------------------------------------------------------------

def setup_two_admins(params):
    cmn.rule_off("~")
    print("\n*** Retry loop — setup_two_admins ***")
    admins_cmn.create_table(params)
    admins_cmn.populate_staff_with_two_admins(params)
    cmn.rule_off("~")

# ------------------------------------------------------------------------------------------

def do_dml_in_retry_loop(start_time, sleep_time, params, sesno, caption, stmt_1, stmt_2):
    print("\n*** Retry loop for " + caption + " — Session " + sesno + " ***")

    sess = cmn.Session(params, "")

    # I used "for j in range(0, 11)" rather than "while True" just as a common-sense safety measure.
    # I've never seen more than 10 or so iterations during my testing.
    # Your mileage might vary.
    # A real program will probably use an infinte loop and a master timeout (say 10 seconds)
    # and break if this is exceeded.
    # Further, a real program would sleep for, say, just 0.1 seconds after each iteration.
    #
    # Here, I sleep fpr a noticeable between the execution of each SQL statement to maximize the chances that
    # these micro-steps from two concurrent invocations of the program will nicely interleave. I do this
    # to maximize the chance of seeing all possible serialization errors after a reasonable number of repetitions
    # of the experiment.
    done = False
    for j in range(0, 11):
        cmn.rule_off("_")
        if j == 0:
            print("First attempt")
        else:
            print("Retry #" + str(j))

        try:
            print(sleep_and_return_time_since_start(start_time, sleep_time) +
                params.sess_1_start_txn_stmt.caption)
            sess.cur.execute(params.sess_1_start_txn_stmt.sql_text)

            t = sleep_and_return_time_since_start(start_time, sleep_time)
            if sesno == '1':
                print(t + stmt_1.caption)
                sess.cur.execute(stmt_1.sql_text)
            elif sesno == '2':
                print(t + stmt_2.caption)
                sess.cur.execute(stmt_2.sql_text)

            print(sleep_and_return_time_since_start(start_time, sleep_time) +
                admins_cmn.Stmts.check_one_or_two_admins.caption)
            sess.cur.execute(admins_cmn.Stmts.check_one_or_two_admins.sql_text)

            rows = sess.cur.fetchall()
            assert (len(rows) == 1), "SQL logic error in check_one_or_two_admins.sql_text"
            if (rows[0][0] == "PASSED!"):
                print("                    PASSED")
                print(sleep_and_return_time_since_start(start_time, sleep_time) + "committing")
                sess.cur.execute("commit")
                done = True

            else:
                sess.cur.execute("rollback")
                print("                    FAILED")
                print(sleep_and_return_time_since_start(start_time, sleep_time) + "rolling back")
                sess.cur.execute("rollback")
                done = True

        except (psycopg2.errors.UniqueViolation) as error:
            sess.cur.execute("rollback")
            done = True
            print("\nHandling UniqueViolation — should tell user 'Staff Name must be unique'")
            print("rolled back")

        except psycopg2.DatabaseError as error:
            sess.cur.execute("rollback")
            if not cmn.is_serialization_error(params.db, "", error.pgcode, error.pgerror):
                raise error

        except Exception:
            raise

        if done:
            break

    sess.close()
    assert done,\
        "Serialization error persists after " + str(j) + " retry attempts"

# ------------------------------------------------------------------------------------------

def show_committed_status(params):
    cmn.rule_off("~")
    print("\n*** Retry loop — Final State ***")
    admins_cmn.show_committed_status(params)
    cmn.rule_off("~")

# ------------------------------------------------------------------------------------------

def main():

    cmn.rule_off("~")
    args = parse_arguments()
    params = cmn.Params(args.db, args.lvl)

    # Single session modes.
    if args.mode == 'setup_one_admin':
        setup_one_admin(params)

    elif args.mode == 'setup_two_admins':
        setup_two_admins(params)

    elif args.mode == 'show_result':
        show_committed_status(params)

    # Modes for two concurrent sessions.
    elif args.mode in (
        'delete_admin', 'update_admin', 'insert_admin',
        'insert_benign', 'insert_collision'):

        if args.start_at is None:
            start_time = datetime.datetime.now()
        else:
            start_time = datetime.datetime.strptime(args.start_at, "%Y-%m-%d %H:%M:%S")
            while datetime.datetime.now() < start_time:
                time.sleep(0.01)

        if args.sesno == "2":
            time.sleep(SLEEP_TIME/2.0)

        if args.mode == 'delete_admin':
            do_dml_in_retry_loop(
                start_time, SLEEP_TIME,
                params, args.sesno,
                "delete_admin",
                admins_cmn.Stmts.delete_admin_alice,
                admins_cmn.Stmts.delete_admin_john)

        elif args.mode == 'update_admin':
            do_dml_in_retry_loop(
                start_time, SLEEP_TIME,
                params, args.sesno,
                "update_admin",
                admins_cmn.Stmts.update_alice_from_admin_to_developer,
                admins_cmn.Stmts.update_john_from_admin_to_sales)

        elif args.mode == 'insert_admin':
            do_dml_in_retry_loop(
                start_time, SLEEP_TIME,
                params, args.sesno,
                "insert_admin",
                admins_cmn.Stmts.insert_alice_as_admin,
                admins_cmn.Stmts.insert_bert_as_admin)

        elif args.mode == 'insert_benign':
            do_dml_in_retry_loop(
                start_time, SLEEP_TIME,
                params, args.sesno,
                "insert_benign",
                admins_cmn.Stmts.insert_alice_as_developer,
                admins_cmn.Stmts.insert_bert_as_sales)

        elif args.mode == 'insert_collision':
            do_dml_in_retry_loop(
                start_time, SLEEP_TIME,
                params, args.sesno,
                "insert_collision",
                admins_cmn.Stmts.insert_alice_as_admin,
                admins_cmn.Stmts.insert_alice_as_developer)

# ------------------------------------------------------------------------------------------

if __name__ == '__main__':
    main()
