"""Retry loop for 'one or two admins' scenario"""

# At the "(venv) $" prompt:
# For example:
#
# python retry_loop.py --mode='setup_two_admins' --db=yb                   > retry_loop_output/setup_two_admins_yb.txt
#
# Snapshot
# python retry_loop.py --mode='delete_admin' --db=yb --lvl=snp --sesno='1' > retry_loop_output/delete_admin_yb_snp_1.txt
# python retry_loop.py --mode='delete_admin' --db=yb --lvl=snp --sesno='2' > retry_loop_output/delete_admin_yb_snp_2.txt
#
# Serializable
# python retry_loop.py --mode='delete_admin' --db=yb --lvl=srl --sesno='1' > retry_loop_output/delete_admin_yb_srl_1.txt
# python retry_loop.py --mode='delete_admin' --db=yb --lvl=srl --sesno='2' > retry_loop_output/delete_admin_yb_srl_2.txt
#
# python retry_loop.py --mode='show_result' --db=yb                        > retry_loop_output/show_result_yb.txt

import argparse
import cmn
import admins_cmn
import psycopg2
import time
import datetime

# ------------------------------------------------------------------------------------------

# The high level aim here is to run two executions of this program concurrently,
# each in its own terminal windows, in such a way that the SQL executions from each
# exactly interleave. The approach is naive, but good enough.
#
# SLEEP_TIME determines the time between "start transaction" and each subsequent
# SQL execution.
#
# Notice the "sesno" command line argument. When it's '1', the program starts immediately.
# And when it's '2', the program sleeps for SLEEP_TIME/2 before starting.
#
# You should aim to start the two concurrent executions as close to simultaneously
# as you can manage to increase the changes of proper interleaving of the SQL executions.
#
# Simply get the "Session 1" and "Session 2" invocation commands ready-to-go at
# the terminal prompt in ach window and then hit "return" in one, and "return" in
# the other as soon after the first as your reaction time allows.
#
# You can see if this approach works for you (it does seem to fr me) by looking at the
# value for "now" that is printed before each SQL statement execution.
#
# If you choose a value for EPOCH_START_STR that's not long before you do the tests,
# then the printed values for "now" (in seconds since the start of the epoch) will
# be small, and therefore fairly easy to read. Otherwise, you could leave the
# shipped value as is. It has no semantic significance.

# Magic numbers (constant)
EPOCH_START_STR = "2019-08-28 14:00:00"
EPOCH_START = datetime.datetime.strptime(EPOCH_START_STR, "%Y-%m-%d %H:%M:%S")
SLEEP_TIME = 4  # seconds

# ------------------------------------------------------------------------------------------

def parse_arguments():
    parser = argparse.ArgumentParser("Isolation Levels Tests")

    parser.add_argument(
        "--mode",
        choices=['setup_two_admins', 'setup_one_admin', 'delete_admin', 'insert_admin', 'insert_collision', 'show_result'],
        default='show_result',
        help="several distinct modes")

    parser.add_argument(
        "--sesno",
        choices=['1', '2'],
        default='1',
        help="Session #")

    parser.add_argument(
        "--db",
        choices=['yb', 'pg'],
        default="yb",
        help="Database: yb to use YugaByte, pg to use Postgres")

    parser.add_argument(
        "--lvl",
        choices=['snp', 'srl'],
        default="snp",
        help="Isolation level: snp for snapshot, srl for serializable")

    return parser.parse_args()

# ------------------------------------------------------------------------------------------

def seconds_since_epoch_start():
    now = datetime.datetime.now()
    delta = now - EPOCH_START
    s = delta.total_seconds()
    return s

# ------------------------------------------------------------------------------------------

def sleep_and_show_now(sleep_time):
    time.sleep(sleep_time)
    now = round(seconds_since_epoch_start())
    print("Now: " + str(now))

# ------------------------------------------------------------------------------------------

def setup_one_admin(params):
    cmn.rule_off("~")
    print("\n*** Retry loop — setup_two_admins ***")
    admins_cmn.create_table(params)
    admins_cmn.populate_staff_with_one_admin(params)
    cmn.rule_off("~")

# ------------------------------------------------------------------------------------------

def setup_two_admins(params):
    cmn.rule_off("~")
    print("\n*** Retry loop — setup_two_admins ***")
    admins_cmn.create_table(params)
    admins_cmn.populate_staff_with_two_admins(params)
    cmn.rule_off("~")

# ------------------------------------------------------------------------------------------

def do_dml__in_retry_loop(params, sesno, sleep_time, caption, stmt_1, stmt_2):
    print("\n*** Retry loop for " + caption + " — Session " + sesno + " ***")

    sess = cmn.Session(params, "")

    # Notice that this is an infinite loop.
    # I've never seen more than 10 or so iterations during my testing.
    # Your mileage might vary.
    # A real program will probably use a master timeout (say 10 seconds)
    # and break if this is exceeded.
    # Further, a real program would sleep for, say, just 0.1 seconds after each iteration.
    #
    # Here, I sleep fpr a noticeable between the execution of each SQL statement to maximize the chances that
    # these micro-steps from two concurrent invocations of the program will nicely interleave. I do this
    # to maximize the chance of seeing all possible serialization errors after a reasonable number of repetitions
    # of the experiment.
    break_now = False
    j = 0
    while True:
        cmn.rule_off("_")
        j = j + 1
        print("Iteration #  " + str(j))
        try:
            sleep_and_show_now(0)
            print(params.sess_1_start_txn_stmt.caption)
            sess.cur.execute(params.sess_1_start_txn_stmt.sql_text)

            sleep_and_show_now(sleep_time)
            if sesno == '1':
                print(stmt_1.caption)
                sess.cur.execute(stmt_1.sql_text)
            elif sesno == '2':
                print(stmt_2.caption)
                sess.cur.execute(stmt_2.sql_text)
            else:
                assert False, "bad sesno: " + sesno

            sleep_and_show_now(sleep_time)
            sess.cur.execute(admins_cmn.Stmts.check_one_or_two_admins.sql_text)
            rows = sess.cur.fetchall()
            assert (len(rows) == 1), "SQL logic error in check_one_or_two_admins.sql_text"
            if (rows[0][0] == "PASSED!"):
                print("check_one_or_two_admins PASSED")
                break_now = True
            else:
                sess.cur.execute("rollback")
                print("check_one_or_two_admins FAILED")
                print("rolled back")
                break_now = True
                break

            sleep_and_show_now(sleep_time)
            print("committing")
            sess.cur.execute("commit")
            break_now = True

        except (psycopg2.errors.UniqueViolation) as error:
            sess.cur.execute("rollback")
            break_now = True
            print("\nHandling UniqueViolation — should tell user 'Staff Name must be unique'")
            print("rolled back")

        except psycopg2.DatabaseError as error:
            sess.cur.execute("rollback")
            break_now = False
            if not cmn.is_serialization_error(params.db, "", error.pgcode, error.pgerror):
                raise error

        except Exception:
            raise

        if break_now:
            break
#       else:
#           time.sleep(0.2)

    sess.close()

# ------------------------------------------------------------------------------------------

def show_committed_status(params):
    cmn.rule_off("~")
    print("\n*** Retry loop — Final State ***")
    admins_cmn.show_committed_status(params)
    cmn.rule_off("~")

# ------------------------------------------------------------------------------------------

def main():

    cmn.rule_off("~")
    args = parse_arguments()
    params = cmn.Params(args.db, args.lvl)

    if args.mode == 'setup_one_admin':
        setup_one_admin(params)

    elif args.mode == 'setup_two_admins':
        setup_two_admins(params)

    elif args.mode in ('delete_admin', 'insert_admin', 'insert_collision'):
        if args.sesno == "2":
            time.sleep(SLEEP_TIME/2.0)

        if args.mode == 'delete_admin':
            do_dml__in_retry_loop(
                params, args.sesno, SLEEP_TIME,
                "delete_admin",
                admins_cmn.Stmts.delete_admin_alice,
                admins_cmn.Stmts.delete_admin_john)

        elif args.mode == 'insert_admin':
            do_dml__in_retry_loop(
                params, args.sesno, SLEEP_TIME,
                "insert_admin",
                admins_cmn.Stmts.insert_alice_as_admin,
                admins_cmn.Stmts.insert_bert_as_admin)

        elif args.mode == 'insert_collision':
            do_dml__in_retry_loop(
                params, args.sesno, SLEEP_TIME,
                "insert_admin",
                admins_cmn.Stmts.insert_alice_as_admin,
                admins_cmn.Stmts.insert_alice_as_developer)

    elif args.mode == 'show_result':
        show_committed_status(params)

# ------------------------------------------------------------------------------------------

if __name__ == '__main__':
    main()
