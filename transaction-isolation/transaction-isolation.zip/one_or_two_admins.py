"""'One or Two Admins' testcase to illustrate transaction isolation levels"""

# At the "(venv) $" prompt:
# python one_or_two_admins.py --db=yb --lvl=snp > one_or_two_admins_output/yb_snp.txt
# python one_or_two_admins.py --db=yb --lvl=srl > one_or_two_admins_output/yb_srl.txt
# python one_or_two_admins.py --db=pg --lvl=snp > one_or_two_admins_output/pg_snp.txt
# python one_or_two_admins.py --db=pg --lvl=srl > one_or_two_admins_output/pg_srl.txt

import argparse
import cmn
import admins_cmn

# ------------------------------------------------------------------------------------------

def parse_arguments():
    parser = argparse.ArgumentParser("Isolation Levels Tests")

    parser.add_argument(
        "--db",
        choices=['yb', 'pg'],
        default="yb",
        help="Database: yb to use YugaByte, pg to use Postgres")

    parser.add_argument(
        "--lvl",
        choices=['snp', 'srl', 'mx1', 'mx2'],
        default="snp",
        help="""
        snp = both sessions snapshot,
        srl = both sessions serializable,
        mx1 = Sees_1 snp & Sess_2 srl,
        mx2 = Sees_1 srl & Sess_2 snp
        """)

    return parser.parse_args()

# ------------------------------------------------------------------------------------------

def check_one_or_two_admins_in_both_sessions(two_sessions):
    # Comment out the call to check_one_or_two_admins in each session
    # to show that it's precisely testing the data rule with a query
    # that causes the serialization error that, in turn, ensures that
    # the data rule is not violated.

    admins_cmn.check_one_or_two_admins(two_sessions.sess_1)
    admins_cmn.check_one_or_two_admins(two_sessions.sess_2)

def do_test_1(params):
    cmn.rule_off("~")
    print("\n\n1. Start with two Admins. Concurrent Admin deletes.")

    admins_cmn.populate_staff_with_two_admins(params)
    two_sessions = cmn.TwoSessions(params)
    two_sessions.sess_1.execute(admins_cmn.Stmts.delete_admin_alice)
    two_sessions.sess_2.execute(admins_cmn.Stmts.delete_admin_john)
    check_one_or_two_admins_in_both_sessions(two_sessions)
    two_sessions.close()
    admins_cmn.show_committed_status(params)

def do_test_2(params):
    cmn.rule_off("~")
    print("\n\n2. Start with two Admins. Concurrent updates away from Admin.")

    admins_cmn.populate_staff_with_two_admins(params)
    two_sessions = cmn.TwoSessions(params)
    two_sessions.sess_1.execute(admins_cmn.Stmts.update_john_from_admin_to_sales)
    two_sessions.sess_2.execute(admins_cmn.Stmts.update_alice_from_admin_to_developer)
    check_one_or_two_admins_in_both_sessions(two_sessions)
    two_sessions.close()
    admins_cmn.show_committed_status(params)

def do_test_3(params):
    cmn.rule_off("~")
    print("\n\n3. Start with one Admin. Concurrent Admin inserts.")

    admins_cmn.populate_staff_with_one_admin(params)
    two_sessions = cmn.TwoSessions(params)
    two_sessions.sess_1.execute(admins_cmn.Stmts.insert_alice_as_admin)
    two_sessions.sess_2.execute(admins_cmn.Stmts.insert_bert_as_admin)
    check_one_or_two_admins_in_both_sessions(two_sessions)
    two_sessions.close()
    admins_cmn.show_committed_status(params)

def do_test_4(params):
    cmn.rule_off("~")
    print("\n\n4. Start with one Admin. Concurrent updates to Admin.")

    admins_cmn.populate_staff_with_one_admin(params)
    two_sessions = cmn.TwoSessions(params)
    two_sessions.sess_1.execute(admins_cmn.Stmts.update_susan_from_sales_to_admin)
    two_sessions.sess_2.execute(admins_cmn.Stmts.update_mary_from_manager_to_admin)
    check_one_or_two_admins_in_both_sessions(two_sessions)
    two_sessions.close()
    admins_cmn.show_committed_status(params)

def do_test_5(params):
    cmn.rule_off("~")
    print("\n\n5. Start with one Admin. Concurrent 'benign' inserts: one Developer and one Sales.")

    admins_cmn.populate_staff_with_one_admin(params)
    two_sessions = cmn.TwoSessions(params)
    two_sessions.sess_1.execute(admins_cmn.Stmts.insert_alice_as_developer)
    two_sessions.sess_2.execute(admins_cmn.Stmts.insert_bert_as_sales)
    check_one_or_two_admins_in_both_sessions(two_sessions)
    two_sessions.close()
    admins_cmn.show_committed_status(params)

# ------------------------------------------------------------------------------------------

def main():
    cmn.rule_off("~")
    print("\n*** One or Two Admins ***")

    args = parse_arguments()
    params = cmn.Params(args.db, args.lvl)
    admins_cmn.create_table(params)

    # Starting with two Admins.
    do_test_1(params)
    do_test_2(params)

    # Starting with one Admin.
    do_test_3(params)
    do_test_4(params)
    do_test_5(params)

# ------------------------------------------------------------------------------------------

if __name__ == '__main__':
    main()
