"""Basic tests to illustrate transaction isolation levels"""

# At the "(venv) $" prompt:
#
# python basic_tests.py --db=yb --lvl=snp --v_unq=n > basic_tests_output/yb_snp_no_v_unq.txt
# python basic_tests.py --db=yb --lvl=srl --v_unq=n > basic_tests_output/yb_srl_no_v_unq.txt
# python basic_tests.py --db=pg --lvl=snp --v_unq=n > basic_tests_output/pg_snp_no_v_unq.txt
# python basic_tests.py --db=pg --lvl=srl --v_unq=n > basic_tests_output/pg_srl_no_v_unq.txt
#
# python basic_tests.py --db=yb --lvl=snp --v_unq=y > basic_tests_output/yb_snp_v_unq.txt
# python basic_tests.py --db=yb --lvl=srl --v_unq=y > basic_tests_output/yb_srl_v_unq.txt
# python basic_tests.py --db=pg --lvl=snp --v_unq=y > basic_tests_output/pg_snp_v_unq.txt
# python basic_tests.py --db=pg --lvl=srl --v_unq=y > basic_tests_output/pg_srl_v_unq.txt

import argparse
import cmn

# Constant LoV for the legal argument choices for the "select_kinds" and "sess_1_select_location" argument of "do_test".
SELECT_KINDS = {'select all':1, 'select by v':2}
SESS_1_SELECT_LOCATIONS = {'none':1, 'at start':2, 'at end':3, 'both':4}
# ------------------------------------------------------------------------------------------

def parse_arguments():
    parser = argparse.ArgumentParser("Isolation Levels Tests")

    parser.add_argument(
        "--db",
        choices=["yb", "pg"],
        default="yb",
        help="Database: yb to use YugaByte DB, pg to use Postgres")

    parser.add_argument(
        "--lvl",
        choices=['snp', 'srl', 'mx1', 'mx2'],
        default="snp",
        help="""
        snp = both sessions snapshot,
        srl = both sessions serializable,
        mx1 = Sees_1 snp & Sess_2 srl,
        mx2 = Sees_1 srl & Sess_2 snp
        """)

    parser.add_argument(
        "--v_unq",
        choices=["n", "y"],
        default="n",
        help="controls 'unique' in 'table t(...,v int not null [unique])'")

    parser.add_argument(
        "--yb_for_blog_part_1",
        choices=["n", "y"],
        default="n",
        help="tests described in the blog")

    parser.add_argument(
        "--yb_for_blog_part_2",
        choices=["n", "y"],
        default="n",
        help="superset of 'yb_tests_for_blog'")

    parser.add_argument(
        "--pg_ok_yb_err",
        choices=["n", "y"],
        default="n",
        help="results_differ between YugaByte DB and Postgres")

    parser.add_argument(
        "--yb_ok_pg_err",
        choices=["n", "y"],
        default="n",
        help="results_differ between YugaByte DB and Postgres")

    return parser.parse_args()

# ------------------------------------------------------------------------------------------

class Stmts:
    drop_table = cmn.Stmt(
        "drop table if exists t",
        "drop table if exists t")

    # Use "create table t(k int primary key)" to avoid
    # serialization errors in tests #3 and #4.

    create_table_without_v_unq = cmn.Stmt(
        "create table t(k int primary key, v int not null)",
        "create table t(k int primary key, v int not null)")

    create_table_with_v_unq = cmn.Stmt(
        "create table t(k int primary key, v int not null unique)",
        "create table t(k int primary key, v int not null unique)")

    delete_from_t = cmn.Stmt(
        "delete from t",
        "delete from t")

    insert_three_rows_into_t = cmn.Stmt(
        "insert three rows into t",
        """
        with s as (select generate_series(1, 3) as a)
        insert into t(k, v) select a as k, a*2 as v from s
        """)

    insert_17_34_into_t = cmn.Stmt(
        "insert into t(k, v) values(17, 34)",
        "insert into t(k, v) values(17, 34)")

    insert_42_84_into_t = cmn.Stmt(
        "insert into t(k, v) values(42, 84)",
        "insert into t(k, v) values(42, 84)")

    update_t_where_k_is_3 = cmn.Stmt(
        "update t set v = 7 where k = 3",
        "update t set v = 7 where k = 3")

    delete_from_t_where_k_is_1 = cmn.Stmt(
        "delete from t where k = 1",
        "delete from t where k = 1")

    select_count_from_t = cmn.Stmt(
        "select count(*) from t",
        "select count(*) from t")

    select_k_from_t_where_v_is_34 = cmn.Stmt(
        "select k from t where v = 34",
        "select k from t where v = 34")

    select_k_from_t_where_v_is_84 = cmn.Stmt(
        "select k from t where v = 84",
        "select k from t where v = 84")

    select_all_from_t = cmn.Stmt(
        "select k, v from t order by v",
        "select k, v from t order by v")

# ------------------------------------------------------------------------------------------

def create_table(params, v_unq):
    # We can safely take advantage of AUTOCOMMIT for these single-session DDLs.
    sess = cmn.Session(params, "", report_stmts = False)

    sess.execute(Stmts.drop_table)

    # parse_arguments() enforces "y" or "n".
    if v_unq == "n":
        print("Table t(k int primary key, v int not null) dropped & created.\n")
        sess.execute(Stmts.create_table_without_v_unq)
    elif v_unq == "y":
        print("Table t(k int primary key, v int not null unique) dropped & created.\n")
        sess.execute(Stmts.create_table_with_v_unq)

    sess.close()

# ------------------------------------------------------------------------------------------

def delete_from_t_and_insert_three_rows(params):
    # We can safely take advantage of AUTOCOMMIT for these single-session DDLs.
    sess = cmn.Session(params, "", report_stmts = False)
    sess.execute(Stmts.delete_from_t)
    sess.execute(Stmts.insert_three_rows_into_t)
    sess.close()
    print("Starting state: 3 rows")

# ------------------------------------------------------------------------------------------

def select_one_column_from_t(sess, stmt, do_rule_off = None):
    sess.execute(stmt, report_stmts = True, do_rule_off = do_rule_off)

    if (not sess.serialization_error):
        rows = sess.cur.fetchall()
        for row in rows:
            print(sess.padding + str(row[0]).rjust(5, " "))

# ------------------------------------------------------------------------------------------

def select_two_columns_from_t(sess, stmt, do_rule_off = None):
    sess.execute(stmt, report_stmts = True, do_rule_off = do_rule_off)

    if (not sess.serialization_error):
        rows = sess.cur.fetchall()
        for row in rows:
            print(sess.padding + str(row[0]).rjust(5, " ") + str(row[1]).rjust(5, " "))

# ------------------------------------------------------------------------------------------

def show_committed_status(params):
    # We can safely take advantage of AUTOCOMMIT for this single-session Query.
    sess = cmn.Session(params, params.sess_1_padding, report_stmts = False)
    select_two_columns_from_t(sess, Stmts.select_all_from_t)
    sess.close()
    print("(Final committed status using separate session)")

# ------------------------------------------------------------------------------------------

def do_test(
    params,
    test_no,
    sess_2_many_txns,
    select_kind,
    sess_1_select,
    sess_1_insert_midway,
    sess_2_select):

    for k, v in SELECT_KINDS.items():
        if v == select_kind:
            select_kind_key = "'" + k + "'"

    for k, v in SESS_1_SELECT_LOCATIONS.items():
        if v == sess_1_select:
            sess_1_select_location = "'" + k + "'"

    cmn.rule_off("~")
    print(
      "\n\nTest_" + str(test_no).zfill(2) + "\n" +

      "  sess_2_many_txns: " + str(sess_2_many_txns)     + "\n" +
      "  select_kind:      " + select_kind_key           + "\n" +
      "  sess_1_select:    " + sess_1_select_location    + "\n" +
      "  sess_1_insert:    " + str(sess_1_insert_midway) + "\n" +
      "  sess_2_select:    " + str(sess_2_select)        + "\n"
    )

    delete_from_t_and_insert_three_rows(params)

    # This device improves the readability of the output.
    # We don't want to rule off between consecutive 'start txn', 'do SQL', and 'commit'.
    if sess_2_many_txns:
        l_do_rule_off = False
    else:
        l_do_rule_off = True

    sess_1 = cmn.Session(params, params.sess_1_padding)
    sess_2 = cmn.Session(params, params.sess_2_padding)

    sess_1.execute(params.sess_1_start_txn_stmt)
    sess_2.execute(params.sess_2_start_txn_stmt)

    # ----------------------------------------------------------------

    if sess_1_select in (SESS_1_SELECT_LOCATIONS['at start'], SESS_1_SELECT_LOCATIONS['both']):
        if select_kind == SELECT_KINDS['select all']:
            select_two_columns_from_t(sess_1, Stmts.select_all_from_t)
        elif select_kind == SELECT_KINDS['select by v']:
            select_one_column_from_t(sess_1, Stmts.select_k_from_t_where_v_is_84)

    # ----------------------------------------------------------------

    sess_2.execute(Stmts.insert_17_34_into_t, do_rule_off = l_do_rule_off)
    if sess_2_many_txns:
        sess_2.commit(do_rule_off = False)

    # ----------------------------------------------------------------

    if sess_2_many_txns:
        sess_2.execute(params.sess_2_start_txn_stmt)
    sess_2.execute(Stmts.update_t_where_k_is_3, do_rule_off = l_do_rule_off)
    if sess_2_many_txns:
        sess_2.commit(do_rule_off = l_do_rule_off)

    # ----------------------------------------------------------------

    if sess_1_insert_midway:
        sess_1.execute(Stmts.insert_42_84_into_t)

    # ----------------------------------------------------------------

    if sess_2_many_txns:
        sess_2.execute(params.sess_2_start_txn_stmt)
    sess_2.execute(Stmts.delete_from_t_where_k_is_1, do_rule_off = l_do_rule_off)
    if sess_2_many_txns:
        sess_2.commit(do_rule_off = l_do_rule_off)

    # ----------------------------------------------------------------

    if sess_2_many_txns:
        sess_2.execute(params.sess_2_start_txn_stmt)

    if sess_2_select:
        if select_kind == SELECT_KINDS['select all']:
            select_two_columns_from_t(sess_2, Stmts.select_all_from_t, do_rule_off = l_do_rule_off)
        elif select_kind == SELECT_KINDS['select by v']:
            select_one_column_from_t(sess_2, Stmts.select_k_from_t_where_v_is_34, do_rule_off = l_do_rule_off)

    if sess_1_select in (SESS_1_SELECT_LOCATIONS['at end'], SESS_1_SELECT_LOCATIONS['both']):
        if select_kind == SELECT_KINDS['select all']:
            select_two_columns_from_t(sess_1, Stmts.select_all_from_t)
        elif select_kind == SELECT_KINDS['select by v']:
            select_one_column_from_t(sess_1, Stmts.select_k_from_t_where_v_is_84)

    sess_2.commit(do_rule_off = l_do_rule_off)
    sess_1.commit()

    sess_1.close()
    sess_2.close()
    show_committed_status(params)

# ------------------------------------------------------------------------------------------

def main():
    # Subsets of the tests to be run for various purposes.
    YB_FOR_BLOG_PART_1  = [3, 12, 29, 42]
    YB_FOR_BLOG_PART_2  = [23, 43, 55]
    PG_OK_YB_ERR        = [4, 5, 6, 9, 10, 13, 14, 20, 27, 28, 36, 37, 38, 60, 63]
    YB_OK_PG_ERR        = [23, 43, 55]
    args = parse_arguments()
    params = cmn.Params(args.db, args.lvl)

    title = "\n*** Basic Tests"
    selection = []

    selection_made = False
    if args.yb_for_blog_part_1 == 'y':
        selection_made = True
        selection = selection + YB_FOR_BLOG_PART_1
        title += " | YB_for_Blog_Part_1"

    if args.yb_for_blog_part_2 == 'y':
        selection_made = True
        selection = selection + YB_FOR_BLOG_PART_2
        title += " — YB_for_Blog_Part_2"

    if args.pg_ok_yb_err == 'y':
        selection_made = True
        selection = selection + PG_OK_YB_ERR
        title += " — PG_ok_YB_err"

    if args.yb_ok_pg_err == 'y':
        selection_made = True
        selection = selection + YB_OK_PG_ERR
        title += " — YB_ok_PG_err"

    title += " ***"

    # Remove the duplicates.

    if selection_made:
        print("selection made")
        selection = list(dict.fromkeys(selection))
    else:
        print("no selection made")
        # Create a list with all possible values for test_no
        # Crude but adequate. There are far fewer tests than 1,000.
        selection = []
        for test_no in range(1000):
            selection.append(test_no + 1)

    cmn.rule_off("~")
    print(title)
    create_table(params, args.v_unq)

    test_no = 0
    for sess_2_many_txns in [False, True]:
        for select_kind in SELECT_KINDS.values():
            for sess_1_select in SESS_1_SELECT_LOCATIONS.values():
                for sess_1_insert_midway in [False, True]:
                    for sess_2_select in [False, True]:
                        test_no += 1
                        # Run only the selected tests.
                        if test_no in selection:
                            do_test(
                                params,
                                test_no,
                                sess_2_many_txns,
                                select_kind,
                                sess_1_select,
                                sess_1_insert_midway,
                                sess_2_select)

# ------------------------------------------------------------------------------------------

if __name__ == '__main__':
    main()
