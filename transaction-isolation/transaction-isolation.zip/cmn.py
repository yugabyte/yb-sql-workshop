"""Common services for programs that illustrate transaction isolation levels"""

import psycopg2

# ------------------------------------------------------------------------------------------

def rule_off(ch):
    t = ch
    for x in range(0, 79):
        t = t + ch
    print(t)

# ------------------------------------------------------------------------------------------

def is_serialization_error(db, padding, err_code, err_text):
    # This is a short-term hack while YugaByte DB doesn't properly construct the exception object
    # of class 'psycopg2.DatabaseError' upon serialization error:
    #   YugaByte/yugabyte-db GitHub issue #1567 (still open in 1.3.1)
    # See also
    #   YugaByte/yugabyte-db GitHub issue #1276 (still open in 1.3.1)
    #   [YSQL] Occasionally getting "Not found: Missing metadata for transaction" error
    #
    # Ultimately, SQL queries that can be expected to encounter serialization errors
    # should be written thus (as presently works in PostgreSQL):
    #
    #     try:
    #       <execute the SQL query>
    #     except psycopg2.errors.SerializationFailure as err:
    #       report serialization failure
    #
    # and then let other (unexpected) exceptions bubble up.
    #
    # More realistically, the <execute the SQL query> would be wrapped in an infinite
    # loop with a sleep and a master time-out to retry time and again until no
    # serialization failure occurs.

    yb_err_subsr_1 = "Conflicts with higher priority transaction"
    yb_err_subsr_2 = "Transaction expired"
    yb_err_subsr_3 = "Missing metadata for transaction"
    yb_err_subsr_4 = "Operation failed. Try again.: Value write after transaction start"
    yb_err_subsr_5 = "Query error: Restart read required"

    pg_err_subsr = "could not serialize access due to read/write dependencies among transactions"

    if db == "yb":
        if (   yb_err_subsr_1 in err_text
            or yb_err_subsr_2 in err_text
            or yb_err_subsr_3 in err_text
            or yb_err_subsr_4 in err_text
            or yb_err_subsr_5 in err_text):
            is_srl_error = True
        else:
            is_srl_error = False

    elif db == "pg":
        if pg_err_subsr in err_text:
            is_srl_error = True
        else:
            is_srl_error = False

    if is_srl_error:
        pos = err_text.find('DETAIL:')
        # starts with "ERROR:  " = 8 characters
        err_text = err_text[8:pos]
        print(padding + "Serialization error, Code: " + str(err_code))
        print(padding + err_text[ 0:39])
        print(padding + err_text[39:75] + "...")
        print(padding + "Rolled back")

    return is_srl_error;

# ------------------------------------------------------------------------------------------

class Params:
    # Attributes:
    # db, port, sess_1_start_txn_stmt, sess_2_start_txn_stmt, sess_1_padding, sess_2_padding
    def __init__(self, db, lvl):
        self.db = db
        self.sess_1_padding = ""
        self.sess_2_padding = " ".ljust(40)

        if db == "yb":
            db_caption = "Using YugaByte DB"
            self.port = "5433"
        elif db == "pg":
            db_caption = "Using Postgres"
            self.port = "5432"
        else:
            # Sanity check: the client's parse_arguments() should enforce "yb" or "pg".
            assert False, "Bad db: " + db

        if lvl == "snp":
            iso_level_caption = "both sessions = snapshot"
            self.sess_1_start_txn_stmt = Stmts.start_snp_txn
            self.sess_2_start_txn_stmt = Stmts.start_snp_txn
        elif lvl == "srl":
            iso_level_caption = "both sessions = serializable"
            self.sess_1_start_txn_stmt = Stmts.start_srl_txn
            self.sess_2_start_txn_stmt = Stmts.start_srl_txn
        elif lvl == "mx1":
            iso_level_caption = "Sess_1 = snp, Sess_2 = srl"
            self.sess_1_start_txn_stmt = Stmts.start_snp_txn
            self.sess_2_start_txn_stmt = Stmts.start_srl_txn
        elif lvl == "mx2":
            iso_level_caption = "Sess_1 = srl, Sess_2 = snp"
            self.sess_1_start_txn_stmt = Stmts.start_srl_txn
            self.sess_2_start_txn_stmt = Stmts.start_snp_txn
        else:
            # Sanity check. the client's parse_arguments() should enforce "snp" or "srl".
            assert False, "Bad lvl: " + lvl

        print("\n" + db_caption + " — " + iso_level_caption)

# ------------------------------------------------------------------------------------------

class Stmt:
    def __init__(self, caption, sql_text):
        self.caption  = caption
        self.sql_text = sql_text

# ------------------------------------------------------------------------------------------

class Stmts:
    # Notice that with "AUTOCOMMIT Off", psycopg2 issues "BEGIN" before
    # executing the first SQL statement that your code executes so that your own
    # "start transaction" would be illegal.
    #
    # Moreover, the behavior of the supplied session.commit() and session.rollback()
    # procedures seems to be strangely affected by the AUTOCOMMIT mode, We prefer
    # therefore to commit and rollback by executing these SQL statements explicitly.
    #
    # All the more reason to avoid "AUTOCOMMIT Off".

    # Notice that PostgreSQL, and therefore YugaByte DB's YSQL by inheritance,
    # use the syntax "repeatable read" to set the level that is properly
    # named "snapshot".

    start_snp_txn = Stmt(
        "start snapshot isolation txn",
        "start transaction isolation level repeatable read")

    start_srl_txn = Stmt(
        "start serializable isolation txn",
        "start transaction isolation level serializable")

    commit = Stmt(
        "commit",
        "commit")

    rollback = Stmt(
        "rollback",
        "rollback")

# ------------------------------------------------------------------------------------------

class Session:
    # The default mode for ysqlsh (inherited from psql) is "AUTOCOMMIT On".
    # Moreover, its *essential* if you want to be able to set the isolation level
    # in a plpgsql procedure. We therefore choose that mode here -- see
    # set_session(autocommit=True) below -- as a discipline so that we are forced
    # to start every multi-statement txn explicitly. As a further discipline,
    # even single statements (when only one is needed) are done in an explicitly
    # started and committed txn.

    def __init__(self, params, padding, report_stmts = True, do_rule_off = True):
        self.params = params
        self.padding = padding
        self.report_stmts = report_stmts
        self.do_rule_off = do_rule_off
        self.serialization_error = False

        if self.report_stmts:
            # No need to take aaccount of self.do_rule_off here.
            rule_off("_")
            print(self.padding + "create session")

        connect_str = "host=localhost dbname=postgres user=postgres port=" + params.port
        self.session = psycopg2.connect(connect_str)

        # We don't need << isolation_level='READ COMMITTED' >>, or any
        # other level, 'cos we will always set the level explicitly.
        self.session.set_session(autocommit=True)
        self.cur = self.session.cursor()

    def execute(self, statement, report_stmts = None, do_rule_off = None):
        if report_stmts is None:
            l_report_stmts = self.report_stmts
        else:
            l_report_stmts = report_stmts

        if do_rule_off is None:
            l_do_rule_off = self.do_rule_off
        else:
            l_do_rule_off = do_rule_off

        # When executing SELECT statements, fetch the results in the calling routine immediately after this,
        # fetching the number of fields that the SELECT defined.

        # Meaningless to execute any subsequent statement after
        # there's been a serialization error during the current txn.
        if not self.serialization_error:
            if l_report_stmts:
                if l_do_rule_off:
                    rule_off("_")
                print(self.padding + statement.caption)

            try:
                self.cur.execute(statement.sql_text)
                self.serialization_error = False
            except psycopg2.DatabaseError as error:
                self.session.rollback()
                if is_serialization_error(self.params.db, self.padding, error.pgcode, error.pgerror):
                    self.serialization_error = True
                else:
                    assert False, "Unexpected database error"

            # Catch-all (like plpgsql's WHEN OTHERS).
            # Must roll back, even if we have no clue what went wrong.
            except Exception:
                self.session.rollback()
                assert False, "Unexpected database error"

        else:
            if l_report_stmts:
                print(self.padding + "Can't continue after serialization err")

    def commit(self, do_rule_off = None):
        if do_rule_off is None:
            l_do_rule_off = self.do_rule_off
        else:
            l_do_rule_off = do_rule_off

        # Meaningless (and wrong) to "commit" if the current txn has already been rolled back.
        if not self.serialization_error:
            if self.report_stmts:
                if l_do_rule_off:
                    rule_off("_")
                print(self.padding + Stmts.commit.caption)

            try:
                # See the comments in class Stmts
                self.cur.execute(Stmts.commit.sql_text)
                self.serialization_error = False
            except psycopg2.DatabaseError as error:
                self.session.rollback()
                if is_serialization_error(self.params.db, self.padding, error.pgcode, error.pgerror):
                    self.serialization_error = True
                else:
                    raise error

        else:
            if self.report_stmts:
                rule_off("_")
                print(self.padding + "'rollback' has already been done")

    def rollback(self):
        if self.report_stmts:
            rule_off("_")
            print(self.padding + Stmts.rollback.sql_text)

        # See the comments in class Stmts
        self.cur.execute(Stmts.rollback.sql_text)

    def close(self):
        if self.session is not None:
            if self.report_stmts:
                rule_off("_")
                print(self.padding + "exit session")
            self.cur.close()
            self.session.close()
            self.session = None

# ------------------------------------------------------------------------------------------

class TwoSessions:
    def __init__(self, params):
        self.sess_1 = Session(params, params.sess_1_padding)
        self.sess_2 = Session(params, params.sess_2_padding)

        self.sess_1.execute(params.sess_1_start_txn_stmt)
        self.sess_2.execute(params.sess_2_start_txn_stmt)

    def close(self):
        # Notice that if a serialization error has been detected,
        # then "commit" will be a no-op and will print
        # "'rollback' has already been done".
        self.sess_1.commit()
        self.sess_2.commit()

        self.sess_1.close()
        self.sess_2.close()
