select
  case
    when job = 'Admin' then '>>>'
  else                      ' '
    end
  as is_staff,
  name,
  job
from staff
order by name;

select 
  case (select count(*) from staff where job = 'Admin') in (1, 2)
    when true then 'PASSED!'
    else           'FAILED!'
  end
  as assertion;
