start transaction;
set transaction isolation level serializable;
delete from staff where name = 'John';
select 
  case (select count(*) from staff where job = 'Admin') in (1, 2)
    when true then 'PASSED!'
    else           'FAILED!'
  end
  as assertion;



-- rollback;
-- delete from staff where name = 'Alice';
