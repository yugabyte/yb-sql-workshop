\set r '\\i run_all.sql'

\set AUTOCOMMIT On
\echo Ensure that there is no ongoing txn
rollback;

\i cr_and_populate_table.sql
\i show_admins.sql
\i start_txn_to_delete_john.sql

\echo 'issue COMMIT by hand when retry_loop.py has exited.'
