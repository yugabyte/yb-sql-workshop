drop table if exists staff cascade;

create table staff(
  name varchar(10)
    constraint staff_name primary key,
  job varchar(10)
    constraint staff_job_id_nn not null
    constraint staff_job_id_chk check (job in (
      'Manager',
      'Admin',
      'Sales',
      'Marketing',
      'Developer')));

insert into staff(name, job) values
  ('Mary',  'Manager'),
  ('Maude', 'Developer'),
  ('Susan', 'Sales'),
  ('Bill',  'Marketing'),
  ('Fred',  'Sales'),
  ('John',  'Admin');

insert into staff(name, job) values ('Alice', 'Admin');
