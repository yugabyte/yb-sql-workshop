The filenames are self-explanatory. Looks at them first, in this order:

1. common.py
2, black_white_marbles.py
3. one_or_two_admins
4. basic_tests.py

Use README.md as the "how to use" source of truth:

https://github.com/YugaByte/yb-sql-workshop/tree/master/isolation-levels