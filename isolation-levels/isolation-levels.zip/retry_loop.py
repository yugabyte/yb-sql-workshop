"""Retry loop for 'one or two admins' isolation levels"""

# At the "(venv) $" prompt:
# python retry_loop.py --db=yb --lvl=snp > retry_loop_output/yb_snp.txt
# python retry_loop.py --db=yb --lvl=srl > retry_loop_output/yb_srl.txt
# python retry_loop.py --db=pg --lvl=snp > retry_loop_output/pg_snp.txt
# python retry_loop.py --db=pg --lvl=srl > retry_loop_output/pg_srl.txt

import common
import psycopg2
import time

# ------------------------------------------------------------------------------------------

def main():
    common.print_test_title("Retry loop.")
    args = common.parse_arguments()
    params = common.Params(args.db, args.lvl)
    sess = common.Session(params, "", report_stmts=True)

    print(params.start_txn_stmt.sql_text)
    sess.cur.execute(params.start_txn_stmt.sql_text)

    n = 3
    for j in range(n):
        print("Iteration #  " + str(j + 1))
        try:
            sess.cur.execute(params.start_txn_stmt.sql_text)
            sess.cur.execute("delete from staff where name = 'Alice'")

            sess.cur.execute(
                """
                select 
                  case (select count(*) from staff where job = 'Admin') in (1, 2)
                    when true then 'PASSED!'
                    else           'FAILED!'
                  end
                  as assertion
                """)

            sess.cur.execute("commit")
            print("commit OK")
            break_now = True
        except psycopg2.DatabaseError as error:
            sess.cur.execute("rollback")
            break_now = False
            if not common.is_serialization_error(params.db, "", error.pgcode, error.pgerror):
                raise error
        except Exception:
            raise

        if break_now:
            break
        else:
            time.sleep(0.2)

    sess.close()
    assert break_now, "Serialization error persists after " + str(n) + " attempts"

# ------------------------------------------------------------------------------------------

if __name__ == '__main__':
    main()
