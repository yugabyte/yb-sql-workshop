\echo select *
select n, c from t order by n;
