begin;
-- set transaction isolation level read committed; -- PG only
   set transaction isolation level repeatable read;
-- set transaction isolation level serializable;
