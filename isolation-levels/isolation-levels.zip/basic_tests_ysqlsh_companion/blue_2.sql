-- Uncomment one of these rows to choose the desired test.
-- Do the same in red_2.sql
--
-- \i insert_same_row/blue_2.sql
-- \i update_same_row/blue_2.sql
   \i delete_same_row/blue_2.sql
