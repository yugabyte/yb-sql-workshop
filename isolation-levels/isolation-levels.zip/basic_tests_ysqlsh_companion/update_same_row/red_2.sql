\echo set c = 42 where n = 2

update t set c = 42 where n = 2;

\echo "update" is has now completed
