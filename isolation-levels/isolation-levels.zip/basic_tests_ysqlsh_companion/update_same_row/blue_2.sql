\echo set c = 17 where n = 2

update t set c = 17 where n = 2;
