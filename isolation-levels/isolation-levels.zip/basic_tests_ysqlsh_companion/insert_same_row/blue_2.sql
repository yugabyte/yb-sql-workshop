\echo set c = 17 where n = 2

insert into t(n, c) values(17, 34);
