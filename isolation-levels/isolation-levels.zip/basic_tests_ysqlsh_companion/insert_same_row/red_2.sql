\echo set c = 42 where n = 2

insert into t(n, c) values(17, 34);

\echo "insert" has now completed
