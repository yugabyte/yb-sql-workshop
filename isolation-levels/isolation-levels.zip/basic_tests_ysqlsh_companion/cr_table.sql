drop table if exists t;
create table t(n integer primary key, c integer not null);
with v as (select generate_series(1, 3) as c)
insert into t(n, c) select c as n, c*2 as c from v;
