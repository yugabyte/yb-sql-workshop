\echo commit and select *

commit;
select n, c from t order by n;
