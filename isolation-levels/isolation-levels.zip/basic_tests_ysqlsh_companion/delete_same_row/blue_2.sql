\echo delete where n = 2

delete from t where n = 2;
