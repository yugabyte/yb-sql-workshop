\echo create and populate table
\echo set isolation level

\set AUTOCOMMIT on
\i ../cr_table.sql
\i ../set_isolation_level.sql
