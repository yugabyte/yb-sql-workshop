# ------------------------------------------------------------------------------------------
# The "black/white marbles" scenario
# ----------------------------------
python black_white_marbles.py --db=yb --lvl=snp > black_white_marbles_output/yb_snp.txt
python black_white_marbles.py --db=yb --lvl=srl > black_white_marbles_output/yb_srl.txt
python black_white_marbles.py --db=pg --lvl=snp > black_white_marbles_output/pg_snp.txt
python black_white_marbles.py --db=pg --lvl=srl > black_white_marbles_output/pg_srl.txt


# ------------------------------------------------------------------------------------------
# The "one or two admins" scenario
# --------------------------------
python one_or_two_admins.py --db=yb --lvl=snp > one_or_two_admins_output/yb_snp.txt
python one_or_two_admins.py --db=yb --lvl=srl > one_or_two_admins_output/yb_srl.txt
python one_or_two_admins.py --db=pg --lvl=snp > one_or_two_admins_output/pg_snp.txt
python one_or_two_admins.py --db=pg --lvl=srl > one_or_two_admins_output/pg_srl.txt


# ------------------------------------------------------------------------------------------
# The basic tests
# ---------------
python basic_tests.py --db=yb --lvl=snp --c_unq=n > basic_tests_output/yb_snp_no_c_unq.txt
python basic_tests.py --db=yb --lvl=srl --c_unq=n > basic_tests_output/yb_srl_no_c_unq.txt
python basic_tests.py --db=pg --lvl=snp --c_unq=n > basic_tests_output/pg_snp_no_c_unq.txt
python basic_tests.py --db=pg --lvl=srl --c_unq=n > basic_tests_output/pg_srl_no_c_unq.txt

python basic_tests.py --db=yb --lvl=snp --c_unq=y > basic_tests_output/yb_snp_c_unq.txt
python basic_tests.py --db=yb --lvl=srl --c_unq=y > basic_tests_output/yb_srl_c_unq.txt
python basic_tests.py --db=pg --lvl=snp --c_unq=y > basic_tests_output/pg_snp_c_unq.txt
python basic_tests.py --db=pg --lvl=srl --c_unq=y > basic_tests_output/pg_srl_c_unq.txt
