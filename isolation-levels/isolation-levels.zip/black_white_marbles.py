"""'Black and White Marbles' testcase for isolation levels"""

# At the "(venv) $" prompt:
# python black_white_marbles.py --db=yb --lvl=snp > black_white_marbles_output/yb_snp.txt
# python black_white_marbles.py --db=yb --lvl=srl > black_white_marbles_output/yb_srl.txt
# python black_white_marbles.py --db=pg --lvl=snp > black_white_marbles_output/pg_snp.txt
# python black_white_marbles.py --db=pg --lvl=srl > black_white_marbles_output/pg_srl.txt

import common

# ------------------------------------------------------------------------------------------

class Stmts:
    drop_table = common.Stmt(
        "drop table",
        "drop table if exists marbles")

    create_table = common.Stmt(
        "create table",
        """
        create table marbles(
          pk integer
            constraint t_pk primary key,
          color text
            constraint t_c1_nn not null
            constraint t_c1_chk check(color in ('black', 'white')))
        """)

    insert_two_rows = common.Stmt(
        "insert one black row and one white row",
        """
        insert into marbles(pk, color) values
          (1, 'black'),
          (2, 'white')
        """)

    show_marbles = common.Stmt(
        "select * from marbles",
        "select pk, color from marbles order by pk")

    set_black_marble_to_white = common.Stmt(
        "set black marble to white",
        "update marbles set color = 'white' where color = 'black'")

    set_white_marble_to_black = common.Stmt(
        "set white marble to black",
        "update marbles set color = 'black' where color = 'white'")

# ------------------------------------------------------------------------------------------

def show_marbles(sess, report_stmts = None):
    # Notice that if a serialization error has been detetcted,
    # then "execute" will be a no-op.
    sess.execute(Stmts.show_marbles, report_stmts)
    if (not sess.serialization_error) and report_stmts:
        rows = sess.cur.fetchall()
        for row in rows:
            print(sess.padding + str(row[0]).ljust(4, ' ') + row[1])

# ------------------------------------------------------------------------------------------

def create_table(params):
    # We can safely take advantage of AUTOCOMMIT for these single-session DDLs.
    sess = common.Session(params, "", report_stmts = False)
    sess.execute(Stmts.drop_table)
    sess.execute(Stmts.create_table)
    sess.close()
    print("Table dropped & created.")

# ------------------------------------------------------------------------------------------

def show_committed_status(params):
    # We can safely take advantage of AUTOCOMMIT for this single-session Query.
    sess = common.Session(params, params.sess_1_padding, report_stmts = False)
    show_marbles(sess, report_stmts = True)
    sess.close()
    print("(Final committed status using separate session.)")

# ------------------------------------------------------------------------------------------

def insert_two_rows(params):
    # We can safely take advantage of AUTOCOMMIT for this single-session Query.
    sess = common.Session(params, "", report_stmts = False)
    sess.execute(Stmts.insert_two_rows)
    print("Inserted two rows (using separate session).")
    show_marbles(sess, report_stmts = True)
    sess.close()

# ------------------------------------------------------------------------------------------

class TwoSessions:
    def __init__(self, params):
        self.sess_1 = common.Session(params, params.sess_1_padding, report_stmts=True)
        self.sess_2 = common.Session(params, params.sess_2_padding, report_stmts=True)

        self.sess_1.execute(params.start_txn_stmt)
        self.sess_2.execute(params.start_txn_stmt)

    def postlude(self):
        # Notice that if a serialization error has been detected,
        # then "commit" will be a no-op and will print
        # "'rollback' has already been done".
        self.sess_1.commit()
        self.sess_2.commit()

        self.sess_1.close()
        self.sess_2.close()

# ------------------------------------------------------------------------------------------

def main():
    args = common.parse_arguments()
    params = common.Params(args.db, args.lvl)
    create_table(params)
    insert_two_rows(params)
    two_sessions = TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.set_black_marble_to_white)
    two_sessions.sess_2.execute(Stmts.set_white_marble_to_black)
    two_sessions.postlude()
    show_committed_status(params)

# ------------------------------------------------------------------------------------------

if __name__ == '__main__':
    main()
