"""'One or Two Admins' testcase for isolation levels"""

# At the "(venv) $" prompt:
# python one_or_two_admins.py --db=yb --lvl=snp > one_or_two_admins_output/yb_snp.txt
# python one_or_two_admins.py --db=yb --lvl=srl > one_or_two_admins_output/yb_srl.txt
# python one_or_two_admins.py --db=pg --lvl=snp > one_or_two_admins_output/pg_snp.txt
# python one_or_two_admins.py --db=pg --lvl=srl > one_or_two_admins_output/pg_srl.txt

import common

# ------------------------------------------------------------------------------------------

class Stmts:
    drop_table = common.Stmt(
        "drop table",
        "drop table if exists staff cascade")

    create_table = common.Stmt(
        "create table",
        """
        create table staff(
          name varchar(10)
            constraint staff_name primary key,
          job varchar(10)
            constraint staff_job_id_nn not null
            constraint staff_job_id_chk check (job in (
              'Manager',
              'Admin',
              'Sales',
              'Marketing',
              'Developer')))
        """)

    delete_all_rows = common.Stmt(
        "delete all rows",
        "delete from staff")

    insert_six_rows = common.Stmt(
        "insert six rows",
        """
        insert into staff(name, job) values
          ('Mary',  'Manager'),
          ('Maude', 'Developer'),
          ('Susan', 'Sales'),
          ('Bill',  'Marketing'),
          ('Fred',  'Sales'),
          ('John',  'Admin')
        """)

    highlight_admins = common.Stmt(
        "highlight the Admin staff",
        """
        select
          case
            when job = 'Admin' then '>>>'
          else                      ' '
            end
          as is_staff,
          name,
          job
        from staff
        order by name
        """)

    check_one_or_two_admins = common.Stmt(
        "check one or two Admin staff",
        """
        select 
          case (select count(*) from staff where job = 'Admin') in (1, 2)
            when true then 'PASSED!'
            else           'FAILED!'
          end
          as assertion
        """)

    insert_alice_as_admin = common.Stmt(
        "insert Alice as Admin",
        "insert into staff(name, job) values ('Alice', 'Admin')")

    insert_alice_as_developer = common.Stmt(
        "insert Alice as Developer",
        "insert into staff(name, job) values ('Alice', 'Developer')")

    insert_bert_as_admin = common.Stmt(
        "insert Bert as Admin",
        "insert into staff(name, job) values ('Bert', 'Admin')")

    insert_bert_as_sales = common.Stmt(
        "insert Bert as Sales",
        "insert into staff(name, job) values ('Bert', 'Sales')")

    delete_admin_john = common.Stmt(
        "delete Admin John",
        "delete from staff where name = 'John'")

    delete_admin_alice = common.Stmt(
        "delete Admin Alice",
        "delete from staff where name = 'Alice'")

    update_susan_from_sales_to_admin = common.Stmt(
        "update Susan from Sales to Admin",
        "update staff set job = 'Admin' where name = 'Susan'")

    update_mary_from_manager_to_admin = common.Stmt(
        "update Mary from Manager to Admin",
        "update staff set job = 'Admin' where name = 'Mary'")

    update_john_from_admin_to_sales = common.Stmt(
        "update John from Admin to Sales",
        "update staff set job = 'Sales' where name = 'John'")

    update_alice_from_admin_to_developer = common.Stmt(
        "update Alice from Admin to Developer",
        "update staff set job = 'Developer' where name = 'Alice'")

# ------------------------------------------------------------------------------------------

def highlight_admins(sess, report_stmts = None):
    sess.execute(Stmts.highlight_admins, report_stmts)

    if (not sess.serialization_error) and report_stmts:
        rows = sess.cur.fetchall()
        for row in rows:
            print(sess.padding + row[0].ljust(4, ' ') + row[1].ljust(8, ' ') + row[2])

# ------------------------------------------------------------------------------------------

def check_one_or_two_admins(sess, report_stmts = None):
    sess.execute(Stmts.check_one_or_two_admins, report_stmts)

    if (not sess.serialization_error) and report_stmts:
        rows = sess.cur.fetchall()
        for row in rows:
            print(sess.padding + row[0])

# ------------------------------------------------------------------------------------------

def show_committed_status(params):
    # We can safely take advantage of AUTOCOMMIT for this single-session Query.
    sess = common.Session(params, params.sess_1_padding, report_stmts = False)
    highlight_admins(sess, report_stmts = True)
    check_one_or_two_admins(sess, report_stmts = True)
    sess.close()
    print("(Final committed status using separate session.)")

# ------------------------------------------------------------------------------------------

def create_table(params):
    # We can safely take advantage of AUTOCOMMIT for these single-session DDLs.
    sess = common.Session(params, "", report_stmts = False)
    sess.execute(Stmts.drop_table)
    sess.execute(Stmts.create_table)
    sess.close()
    print("Table dropped & created.")

# ------------------------------------------------------------------------------------------

def populate_staff_with_one_admin(params):
    print("Starting state.")

    # We can safely take advantage of AUTOCOMMIT for these single-session DMLs.
    sess = common.Session(params, "", report_stmts = False)
    sess.execute(Stmts.delete_all_rows)
    sess.execute(Stmts.insert_six_rows)
    highlight_admins(sess, report_stmts = True)
    check_one_or_two_admins(sess, report_stmts = True)
    sess.close()

# ------------------------------------------------------------------------------------------

def populate_staff_with_two_admins(params):
    print("Starting state.")

    # We can safely take advantage of AUTOCOMMIT for these single-session DMLs.
    sess = common.Session(params, "", report_stmts = False)
    sess.execute(Stmts.delete_all_rows)
    sess.execute(Stmts.insert_six_rows)
    sess.execute(Stmts.insert_alice_as_admin)
    highlight_admins(sess, report_stmts = True)
    check_one_or_two_admins(sess, report_stmts = True)
    sess.close()

# ------------------------------------------------------------------------------------------

class TwoSessions:
    def __init__(self, params):
        self.sess_1 = common.Session(params, params.sess_1_padding, report_stmts=True)
        self.sess_2 = common.Session(params, params.sess_2_padding, report_stmts=True)

        self.sess_1.execute(params.start_txn_stmt)
        self.sess_2.execute(params.start_txn_stmt)

    def postlude(self):
        # Comment out the call to check_one_or_two_admins in each session
        # to show that it's precisely testing the data rule with a query
        # that causes the serialization error that, in turn, ensures that
        # the data rule is not violated.

        check_one_or_two_admins(self.sess_1, report_stmts=True)
        check_one_or_two_admins(self.sess_2, report_stmts=True)

        self.sess_1.commit()
        self.sess_2.commit()

        self.sess_1.close()
        self.sess_2.close()

# ------------------------------------------------------------------------------------------

def do_test_1(params):
    common.print_test_title("1. Start with two Admins. Concurrent Admin deletes.")

    populate_staff_with_two_admins(params)
    two_sessions = TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.delete_admin_alice)
    two_sessions.sess_2.execute(Stmts.delete_admin_john)
    two_sessions.postlude()
    show_committed_status(params)

def do_test_2(params):
    common.print_test_title("2. Start with two Admins. Concurrent updates away from Admin.")

    populate_staff_with_two_admins(params)
    two_sessions = TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.update_john_from_admin_to_sales)
    two_sessions.sess_2.execute(Stmts.update_alice_from_admin_to_developer)
    two_sessions.postlude()
    show_committed_status(params)

def do_test_3(params):
    common.print_test_title("3. Start with one Admin. Concurrent Admin inserts.")

    populate_staff_with_one_admin(params)
    two_sessions = TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.insert_alice_as_admin)
    two_sessions.sess_2.execute(Stmts.insert_bert_as_admin)
    two_sessions.postlude()
    show_committed_status(params)

def do_test_4(params):
    common.print_test_title("4. Start with one Admin. Concurrent updates to Admin.")

    populate_staff_with_one_admin(params)
    two_sessions = TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.update_susan_from_sales_to_admin)
    two_sessions.sess_2.execute(Stmts.update_mary_from_manager_to_admin)
    two_sessions.postlude()
    show_committed_status(params)

def do_test_5(params):
    common.print_test_title("5. Start with one Admin. Concurrent 'benign' inserts: one Developer and one Sales.")

    populate_staff_with_one_admin(params)
    two_sessions = TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.insert_alice_as_developer)
    two_sessions.sess_2.execute(Stmts.insert_bert_as_sales)
    two_sessions.postlude()
    show_committed_status(params)

# ------------------------------------------------------------------------------------------

def main():
    args = common.parse_arguments()
    params = common.Params(args.db, args.lvl)
    create_table(params)

    # Starting with two Admins.
    do_test_1(params)
    do_test_2(params)

    # Starting with one Admin.
    do_test_3(params)
    do_test_4(params)
    do_test_5(params)

# ------------------------------------------------------------------------------------------

if __name__ == '__main__':
    main()
