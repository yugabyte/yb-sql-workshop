"""Basic tests for isolation levels"""

# At the "(venv) $" prompt:
#
# python basic_tests.py --db=yb --lvl=snp --c_unq=n > basic_tests_output/yb_snp_no_c_unq.txt
# python basic_tests.py --db=yb --lvl=srl --c_unq=n > basic_tests_output/yb_srl_no_c_unq.txt
# python basic_tests.py --db=pg --lvl=snp --c_unq=n > basic_tests_output/pg_snp_no_c_unq.txt
# python basic_tests.py --db=pg --lvl=srl --c_unq=n > basic_tests_output/pg_srl_no_c_unq.txt
#
# python basic_tests.py --db=yb --lvl=snp --c_unq=y > basic_tests_output/yb_snp_c_unq.txt
# python basic_tests.py --db=yb --lvl=srl --c_unq=y > basic_tests_output/yb_srl_c_unq.txt
# python basic_tests.py --db=pg --lvl=snp --c_unq=y > basic_tests_output/pg_snp_c_unq.txt
# python basic_tests.py --db=pg --lvl=srl --c_unq=y > basic_tests_output/pg_srl_c_unq.txt

import common

# ------------------------------------------------------------------------------------------

class Stmts:
    drop_table = common.Stmt(
        "drop table if exists t",
        "drop table if exists t")

    # Use "create table t(n integer primary key)" to avoid
    # serialization errors in tests #3 and #4.

    create_table_no_c_unq = common.Stmt(
        "create table t(n integer primary key, c integer not null)",
        "create table t(n integer primary key, c integer not null)")

    create_table_with_c_unq = common.Stmt(
        "create table t(n integer primary key, c integer not null unique)",
        "create table t(n integer primary key, c integer not null unique)")

    delete_from_t = common.Stmt(
        "delete from t",
        "delete from t")

    insert_three_rows_into_t = common.Stmt(
        "insert three rows into t",
        """
        with v as (select generate_series(1, 3) as c)
        insert into t(n, c) select c as n, c*2 as c from v;
        """)

    insert_17_into_t = common.Stmt(
        "insert into t(n, c) values(17, 34)",
        "insert into t(n, c) values(17, 34)")

    insert_42_into_t = common.Stmt(
        "insert into t(n, c) values(42, 84)",
        "insert into t(n, c) values(42, 84)")

    update_t_where_n_is_2 = common.Stmt(
        "update t set c = 7 where n = 3",
        "update t set c = 7 where n = 3")

    delete_from_t_where_n_is_1 = common.Stmt(
        "delete from t where n = 1",
        "delete from t where n = 1")

    select_count_from_t = common.Stmt(
        "select count(*) from t",
        "select count(*) from t")

    select_count_from_t_where_c_is_34 = common.Stmt(
        "select count(*) from t where c = 34",
        "select count(*) from t where c = 34")

    select_count_from_t_where_c_is_84 = common.Stmt(
        "select count(*) from t where c = 84",
        "select count(*) from t where c = 84")

    test_assertion = common.Stmt(
        "test assertion",
        """
        select 
          case (select count(*) from t where c = 99) in (1, 2)
            when true then '1 or 2 rows with c = 99'
            else           'no rows with c = 99'
          end
          as assertion
        """)

    select_all_from_t = common.Stmt(
        "select n, c from t order by n",
        "select n, c from t order by n")

# ------------------------------------------------------------------------------------------

def create_table(params, c_unq):
    # We can safely take advantage of AUTOCOMMIT for these single-session DDLs.
    sess = common.Session(params, "", report_stmts = False)

    sess.execute(Stmts.drop_table)

    if c_unq == "n":
        print("Table t(n integer primary key, c integer not null) dropped & created.")
        sess.execute(Stmts.create_table_no_c_unq)
    elif c_unq == "y":
        print("Table t(n integer primary key, c integer not null unique) dropped & created.")
        sess.execute(Stmts.create_table_with_c_unq)
    else:
        # Sanity check. common.parse_arguments() should enforce "y" or "n".
        print("Bad c_unq: " + pk)
        exit(102)

    sess.close()

# ------------------------------------------------------------------------------------------

def delete_from_t(params):
    # We can safely take advantage of AUTOCOMMIT for these single-session DDLs.
    sess = common.Session(params, "", report_stmts = False)
    sess.execute(Stmts.delete_from_t)
    sess.close()
    print("Starting state: no rows")

# ------------------------------------------------------------------------------------------

def delete_from_t_and_insert_three_rows(params):
    # We can safely take advantage of AUTOCOMMIT for these single-session DDLs.
    sess = common.Session(params, "", report_stmts = False)
    sess.execute(Stmts.delete_from_t)
    sess.execute(Stmts.insert_three_rows_into_t)
    sess.close()
    print("Starting state: 3 rows")

# ------------------------------------------------------------------------------------------

def select_one_column_from_t(sess, stmt, report_stmts = None):
    sess.execute(stmt, report_stmts)

    if (not sess.serialization_error) and report_stmts:
        rows = sess.cur.fetchall()
        for row in rows:
            print(sess.padding + str(row[0]).rjust(5, " "))

# ------------------------------------------------------------------------------------------

def select_two_columns_from_t(sess, stmt, report_stmts = None):
    sess.execute(stmt, report_stmts)

    if (not sess.serialization_error) and report_stmts:
        rows = sess.cur.fetchall()
        for row in rows:
            print(sess.padding + str(row[0]).rjust(5, " ") + str(row[1]).rjust(5, " "))

# ------------------------------------------------------------------------------------------

def show_committed_status(params):
    # We can safely take advantage of AUTOCOMMIT for this single-session Query.
    sess = common.Session(params, params.sess_1_padding, report_stmts = False)
    select_two_columns_from_t(sess, Stmts.select_all_from_t, report_stmts = True)
    sess.close()
    print("(Final committed status using separate session)")

# ------------------------------------------------------------------------------------------

class TwoSessions:
    def __init__(self, params):
        self.sess_1 = common.Session(params, params.sess_1_padding, report_stmts=True)
        self.sess_2 = common.Session(params, params.sess_2_padding, report_stmts=True)

        self.sess_1.execute(params.start_txn_stmt)
        self.sess_2.execute(params.start_txn_stmt)

    def postlude(self):
        self.sess_1.commit()
        self.sess_2.commit()

        self.sess_1.close()
        self.sess_2.close()

# ------------------------------------------------------------------------------------------

def do_test_1(params):
    common.print_test_title("1. One session inserts, udates,deletes — other session then selects.")
    delete_from_t_and_insert_three_rows(params)
    two_sessions = TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.insert_17_into_t)
    two_sessions.sess_1.execute(Stmts.insert_42_into_t)
    two_sessions.sess_1.execute(Stmts.update_t_where_n_is_2)
    two_sessions.sess_1.execute(Stmts.delete_from_t_where_n_is_1)
    select_two_columns_from_t(two_sessions.sess_1, Stmts.select_all_from_t, report_stmts=True)
    select_two_columns_from_t(two_sessions.sess_2, Stmts.select_all_from_t, report_stmts=True)
    two_sessions.postlude()
    show_committed_status(params)

def do_test_2(params):
    common.print_test_title("2. Concurrent non-conflicting inserts from two sessions (no query)")
    delete_from_t(params)
    two_sessions = TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.insert_17_into_t)
    two_sessions.sess_2.execute(Stmts.insert_42_into_t)
    two_sessions.postlude()
    show_committed_status(params)

def do_test_3(params):
    common.print_test_title("3. Concurrent non-conflicting inserts from two sessions with 'select count(*)'.")
    delete_from_t(params)
    two_sessions = TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.insert_17_into_t)
    two_sessions.sess_2.execute(Stmts.insert_42_into_t)
    select_one_column_from_t(two_sessions.sess_1, Stmts.select_count_from_t, report_stmts=True)
    select_one_column_from_t(two_sessions.sess_2, Stmts.select_count_from_t, report_stmts=True)
    two_sessions.postlude()
    show_committed_status(params)

def do_test_4(params):
    common.print_test_title("4. Concurrent non-conflicting inserts from two sessions with restricted 'select count(*)'.")
    delete_from_t(params)
    two_sessions = TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.insert_17_into_t)
    two_sessions.sess_2.execute(Stmts.insert_42_into_t)
    select_one_column_from_t(two_sessions.sess_1, Stmts.select_count_from_t_where_c_is_34, report_stmts=True)
    select_one_column_from_t(two_sessions.sess_2, Stmts.select_count_from_t_where_c_is_84, report_stmts=True)
    two_sessions.postlude()
    show_committed_status(params)

def do_test_5(params):
    common.print_test_title("5. Concurrent non-conflicting inserts from two sessions with 'test assertion'.")
    delete_from_t(params)
    two_sessions = TwoSessions(params)
    two_sessions.sess_1.execute(Stmts.insert_17_into_t)
    two_sessions.sess_2.execute(Stmts.insert_42_into_t)
    select_one_column_from_t(two_sessions.sess_1, Stmts.test_assertion, report_stmts=True)
    select_one_column_from_t(two_sessions.sess_2, Stmts.test_assertion, report_stmts=True)
    two_sessions.postlude()
    show_committed_status(params)

# ------------------------------------------------------------------------------------------

def main():
    args = common.parse_arguments()
    params = common.Params(args.db, args.lvl)
    create_table(params, args.c_unq)

    do_test_1(params)
    do_test_2(params)
    do_test_3(params)
    do_test_4(params)
    do_test_5(params)

# ------------------------------------------------------------------------------------------

if __name__ == '__main__':
    main()
